pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // مستودع XDcobra لمكتبة Sherpa-ONNX (يُستعمل فقط عند -PwithMoonshine=true).
        // محصور بمجموعة واحدة حتى لا يُستعمل لأي مكتبة أخرى.
        maven {
            url = uri("https://xdcobra.github.io/maven/")
            content { includeGroup("com.xdcobra.sherpa") }
        }
    }
}
rootProject.name = "SubGenius"
include(":app")
