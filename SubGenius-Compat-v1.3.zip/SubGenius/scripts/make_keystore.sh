#!/usr/bin/env bash
# ينشئ مفتاح نشر خاصاً بك مرة واحدة، ويطبع القيم الأربع المطلوبة لـ GitHub Secrets.
# الاستعمال:  bash scripts/make_keystore.sh [alias]
# (على Termux:  pkg install openjdk-17 openssl-tool)
set -e
ALIAS="${1:-subgenius}"
PASS="$(openssl rand -base64 24 | tr -dc 'A-Za-z0-9' | cut -c1-20)"
keytool -genkeypair -v -keystore release.keystore -alias "$ALIAS" -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass "$PASS" -keypass "$PASS" -dname "CN=SubGenius, O=SubGenius, C=EG"
echo
echo "=============== أضف هذه الأسرار في GitHub ==============="
echo "(Settings → Secrets and variables → Actions → New repository secret)"
echo "KEYSTORE_PASSWORD = $PASS"
echo "KEY_ALIAS         = $ALIAS"
echo "KEY_PASSWORD      = $PASS"
echo "KEYSTORE_BASE64   = (النص الطويل التالي)"
base64 -w0 release.keystore 2>/dev/null || base64 release.keystore | tr -d '\n'
echo
echo "=========================================================="
echo "احتفظ بملف release.keystore وكلمة المرور في مكان آمن (نسخة احتياطية). لا ترفعهما إلى GitHub."
