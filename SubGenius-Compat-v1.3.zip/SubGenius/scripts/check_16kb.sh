#!/usr/bin/env bash
# يفحص محاذاة مكتبات .so داخل APK لصفحات 16KB (مطلوب في Google Play). الاستعمال: bash scripts/check_16kb.sh app.apk
set -u
APK="${1:?usage: check_16kb.sh <apk>}"
NDK="${ANDROID_NDK_LATEST_HOME:-$(ls -d "${ANDROID_HOME:-/usr/local/lib/android/sdk}"/ndk/* 2>/dev/null | tail -1)}"
READELF="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-readelf"
[ -x "$READELF" ] || { echo "llvm-readelf not found; skipping"; exit 0; }
TMP="$(mktemp -d)"; unzip -q "$APK" 'lib/*' -d "$TMP" 2>/dev/null || { echo "no native libs"; exit 0; }
bad=0
while IFS= read -r so; do
  align=$("$READELF" -lW "$so" | awk '/LOAD/ {print $NF}' | sort -u | tr '\n' ' ')
  case "$align" in
    *0x1000*) echo "FAIL (4KB): ${so#$TMP/} [$align]"; bad=1 ;;
    *)        echo "ok: ${so#$TMP/} [$align]" ;;
  esac
done < <(find "$TMP/lib" -name '*.so')
exit $bad
