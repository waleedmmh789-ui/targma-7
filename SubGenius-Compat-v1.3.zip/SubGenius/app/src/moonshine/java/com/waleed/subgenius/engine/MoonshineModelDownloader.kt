package com.waleed.subgenius.engine

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Downloads and safely extracts the quantized Arabic Moonshine v2 model. */
object MoonshineModelDownloader {
    const val AVAILABLE = true
    const val MODEL_DIR = "sherpa-moonshine-ar"
    private const val URL_MODEL = "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-moonshine-base-ar-quantized-2026-02-27.tar.bz2"

    fun modelDir(context: Context) = File(context.filesDir, MODEL_DIR)
    fun isDownloaded(context: Context): Boolean {
        val d = modelDir(context)
        return File(d, "encoder_model.ort").isFile && File(d, "decoder_model_merged.ort").isFile && File(d, "tokens.txt").isFile
    }

    suspend fun download(context: Context, onProgress: (Int) -> Unit = {}): Result<String> = withContext(Dispatchers.IO) {
        val target = modelDir(context)
        val archive = File(context.cacheDir, "moonshine-ar.tar.bz2.part")
        try {
            val conn = (URL(URL_MODEL).openConnection() as HttpURLConnection).apply {
                connectTimeout = 20000; readTimeout = 60000; instanceFollowRedirects = true
            }
            try {
                conn.connect()
                if (conn.responseCode !in 200..299) error("تنزيل نموذج Moonshine فشل: HTTP ${conn.responseCode}")
                val total = conn.contentLengthLong
                var count = 0L
                conn.inputStream.use { input -> FileOutputStream(archive).use { output ->
                    val buffer = ByteArray(32 * 1024)
                    while (true) {
                        val n = input.read(buffer); if (n < 0) break
                        output.write(buffer, 0, n); count += n
                        if (total > 0) onProgress(((count * 45 / total).toInt()).coerceIn(0, 45))
                    }
                } }
            } finally { conn.disconnect() }
            val staging = File(context.filesDir, "$MODEL_DIR.tmp")
            staging.deleteRecursively(); staging.mkdirs()
            TarArchiveInputStream(BZip2CompressorInputStream(BufferedInputStream(archive.inputStream()))).use { tar ->
                while (true) {
                    val entry = tar.nextTarEntry ?: break
                    val out = File(staging, entry.name)
                    if (!out.canonicalPath.startsWith(staging.canonicalPath + File.separator)) throw SecurityException("Unsafe model archive path")
                    if (entry.isDirectory) out.mkdirs() else {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { output ->
                            val buffer = ByteArray(32 * 1024)
                            while (true) { val n = tar.read(buffer); if (n < 0) break; output.write(buffer, 0, n) }
                        }
                    }
                }
            }
            val modelRoot = findModelRoot(staging) ?: error("ملفات نموذج Moonshine غير مكتملة")
            val finalStage = File(context.filesDir, "$MODEL_DIR.ready")
            finalStage.deleteRecursively()
            if (modelRoot == staging) {
                if (!staging.renameTo(finalStage)) error("تعذر تجهيز ملفات النموذج")
            } else {
                modelRoot.copyRecursively(finalStage, overwrite = true)
                staging.deleteRecursively()
            }
            if (!File(finalStage, "encoder_model.ort").isFile || !File(finalStage, "decoder_model_merged.ort").isFile || !File(finalStage, "tokens.txt").isFile) {
                finalStage.deleteRecursively(); error("ملفات نموذج Moonshine غير مكتملة")
            }
            target.deleteRecursively()
            if (!finalStage.renameTo(target)) { finalStage.copyRecursively(target, overwrite = true); finalStage.deleteRecursively() }
            onProgress(100)
            Result.success(target.absolutePath)
        } catch (e: Exception) { Result.failure(e) }
        finally { archive.delete() }
    }

    private fun findModelRoot(root: File): File? {
        if (File(root, "encoder_model.ort").isFile) return root
        root.walkTopDown().firstOrNull { it.isDirectory && File(it, "encoder_model.ort").isFile }?.let { return it }
        return null
    }
}
