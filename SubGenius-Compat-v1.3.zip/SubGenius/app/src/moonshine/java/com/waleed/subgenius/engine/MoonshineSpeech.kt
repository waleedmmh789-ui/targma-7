package com.waleed.subgenius.engine

import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineMoonshineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import kotlin.coroutines.coroutineContext

/** Moonshine v2 Arabic ASR. Input is raw PCM s16le, 16 kHz, mono. */
object MoonshineSpeech {
    const val AVAILABLE = true
    private const val SAMPLE_RATE = 16000
    private const val BYTES_PER_SAMPLE = 2
    private const val CHUNK_SECONDS = 15

    suspend fun transcribe(pcmFile: File, modelDir: String, onProgress: (Int) -> Unit = {}): Result<List<SpeechSegment>> =
        withContext(Dispatchers.Default) {
            var recognizer: OfflineRecognizer? = null
            try {
                require(pcmFile.isFile && pcmFile.length() >= 2) { "ملف الصوت فارغ" }
                val dir = File(modelDir)
                val encoder = File(dir, "encoder_model.ort")
                val decoder = File(dir, "decoder_model_merged.ort")
                val tokens = File(dir, "tokens.txt")
                require(encoder.isFile && decoder.isFile && tokens.isFile) { "نموذج Moonshine غير مكتمل؛ أعد تنزيله" }
                val model = OfflineModelConfig(
                    moonshine = OfflineMoonshineModelConfig(encoder = encoder.absolutePath, mergedDecoder = decoder.absolutePath),
                    tokens = tokens.absolutePath,
                    numThreads = 1,
                    provider = "cpu"
                )
                recognizer = OfflineRecognizer(config = OfflineRecognizerConfig(modelConfig = model))
                val bytesPerChunk = CHUNK_SECONDS * SAMPLE_RATE * BYTES_PER_SAMPLE
                val total = pcmFile.length()
                val segments = mutableListOf<SpeechSegment>()
                RandomAccessFile(pcmFile, "r").use { input ->
                    val buffer = ByteArray(bytesPerChunk)
                    var offset = 0L
                    while (offset < total) {
                        coroutineContext.ensureActive()
                        val wanted = minOf(buffer.size.toLong(), total - offset).toInt()
                        var got = 0
                        while (got < wanted) { val n = input.read(buffer, got, wanted - got); if (n < 0) break; got += n }
                        if (got < 2) break
                        val sampleCount = got / 2
                        val samples = FloatArray(sampleCount)
                        var j = 0
                        for (i in 0 until sampleCount) {
                            val lo = buffer[j++].toInt() and 0xff
                            val hi = buffer[j++].toInt()
                            val sample = (hi shl 8) or lo
                            samples[i] = sample / 32768.0f
                        }
                        val stream = recognizer.createStream()
                        try {
                            stream.acceptWaveform(samples, sampleRate = SAMPLE_RATE)
                            recognizer.decode(stream)
                            val text = recognizer.getResult(stream).text.trim()
                            if (text.isNotEmpty()) {
                                val start = offset * 1000 / (SAMPLE_RATE * BYTES_PER_SAMPLE)
                                val end = (offset + got) * 1000 / (SAMPLE_RATE * BYTES_PER_SAMPLE)
                                segments += SpeechSegment(text, start, maxOf(end, start + 500))
                            }
                        } finally { stream.release() }
                        offset += got
                        onProgress(((offset * 100) / total).toInt().coerceIn(0, 99))
                    }
                }
                onProgress(100)
                Result.success(segments)
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { Result.failure(e) }
            finally { runCatching { recognizer?.release() } }
        }
}
