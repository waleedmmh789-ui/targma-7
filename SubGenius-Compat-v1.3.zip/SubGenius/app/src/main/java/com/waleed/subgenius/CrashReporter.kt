package com.waleed.subgenius

import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/** يحفظ نص آخر انهيار (Java/Kotlin) ويعرضه في التشغيل التالي ليسهل إرساله للمطوّر */
object CrashReporter {
    private const val FILE = "last_crash.txt"

    fun install(context: Context) {
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                File(app.filesDir, FILE).writeText(
                    "Thread: ${t.name}\nAndroid ${Build.VERSION.SDK_INT} / ${Build.MANUFACTURER} ${Build.MODEL} / ${Build.SUPPORTED_ABIS.joinToString()}\n\n$sw"
                )
            }
            previous?.uncaughtException(t, e)
        }
    }

    fun read(context: Context): String? =
        File(context.filesDir, FILE).takeIf { it.exists() }?.readText()?.take(6000)

    fun clear(context: Context) {
        runCatching { File(context.filesDir, FILE).delete() }
    }
}
