package com.waleed.subgenius.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.sp
import com.waleed.subgenius.tr

/** يعرض نص آخر انهيار حدث للتطبيق لتصويره أو نسخه وإرساله للمطوّر */
@Composable
fun CrashDialog(report: String, onClose: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(tr("حدث خطأ في التشغيل السابق", "An error occurred in the previous run")) },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(report, fontSize = 11.sp) } },
        confirmButton = {
            TextButton(onClick = { clipboard.setText(AnnotatedString(report)) }) { Text(tr("نسخ النص", "Copy text")) }
        },
        dismissButton = { TextButton(onClick = onClose) { Text(tr("إغلاق", "Close")) } }
    )
}
