package com.waleed.subgenius

import android.graphics.Color as AColor
import androidx.core.content.ContextCompat
import androidx.activity.result.contract.ActivityResultContracts
import android.os.Build
import android.content.pm.PackageManager
import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.navigation.compose.rememberNavController
import com.waleed.subgenius.engine.SpeechToText
import com.waleed.subgenius.ui.AppViewModel
import com.waleed.subgenius.ui.components.CrashDialog
import com.waleed.subgenius.ui.navigation.NavGraph
import com.waleed.subgenius.ui.theme.BgDark
import com.waleed.subgenius.ui.theme.SubGeniusTheme

class MainActivity : ComponentActivity() {
    private val appViewModel: AppViewModel by viewModels()
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        // عند الذهاب للخلفية نحرّر نموذج Vosk المخزّن (إن لم تكن هناك معالجة جارية)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) { SpeechToText.releaseModel(); com.waleed.subgenius.engine.WhisperSpeech.releaseModel() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashReporter.install(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        AppLang.init(this)
        Thread {
            val prefixes = listOf("input_", "compressed_", "burned_", "audio_", "subs_", "vosk_", "chunk_", "dub_", "dubbed_", "tts_")
            cacheDir.listFiles()?.forEach { f ->
                if (f.isFile && prefixes.any { f.name.startsWith(it) }) runCatching { f.delete() }
            }
        }.start()
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        setContent {
            SubGeniusTheme {
                CompositionLocalProvider(LocalLayoutDirection provides (if (AppLang.isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr)) {
                    var crash by remember { mutableStateOf(CrashReporter.read(this@MainActivity)) }
                    Surface(Modifier.fillMaxSize(), color = BgDark) {
                        Scaffold(containerColor = BgDark, contentWindowInsets = WindowInsets.safeDrawing) { padding ->
                            NavGraph(
                                navController = rememberNavController(),
                                appViewModel = appViewModel,
                                modifier = Modifier.padding(padding)
                            )
                        }
                    }
                    crash?.let { report ->
                        CrashDialog(report, onClose = { CrashReporter.clear(this@MainActivity); crash = null })
                    }
                }
            }
        }
    }
}
