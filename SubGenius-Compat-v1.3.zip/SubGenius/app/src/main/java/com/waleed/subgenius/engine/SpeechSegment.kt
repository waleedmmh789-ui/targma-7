package com.waleed.subgenius.engine

data class SpeechSegment(val text: String, val startMs: Long, val endMs: Long)
