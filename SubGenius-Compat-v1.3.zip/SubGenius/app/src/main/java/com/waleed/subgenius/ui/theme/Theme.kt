package com.waleed.subgenius.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColors = darkColorScheme(
    primary = Primary, secondary = Secondary, background = BgDark,
    surface = SurfaceDark, onPrimary = TextWhite, onSecondary = TextWhite,
    onBackground = TextWhite, onSurface = TextWhite, error = ErrRed
)

@Composable
fun SubGeniusTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}
