package com.waleed.subgenius.engine

import com.waleed.subgenius.tr

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import java.io.File

object MediaSaver {
    /** يحفظ الفيديو في معرض الصور (Movies/SubGenius). يعمل على أندرويد 7 فما فوق */
    fun saveToGallery(context: Context, file: File, displayName: String): Uri? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) saveScoped(context, file, displayName)
        else saveLegacy(context, file, displayName)
    } catch (e: Exception) { null }

    private fun saveScoped(context: Context, file: File, displayName: String): Uri? {
        if (!file.exists() || !file.isFile || file.length() <= 0L) return null
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "$displayName.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/SubGenius")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            val output = resolver.openOutputStream(uri, "w") ?: throw IllegalStateException("cannot open output")
            output.use { out -> file.inputStream().use { input -> input.copyTo(out) } }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            if (resolver.update(uri, values, null, null) <= 0) throw IllegalStateException("cannot finish save")
            uri
        } catch (_: Exception) {
            // نحذف السجل غير المكتمل حتى لا يبقى ملف شبحي بحالة IS_PENDING
            runCatching { resolver.delete(uri, null, null) }
            null
        }
    }

    /** أندرويد 7 إلى 9: نكتب الملف مباشرة (يحتاج WRITE_EXTERNAL_STORAGE) ثم نسجله في MediaStore */
    @Suppress("DEPRECATION")
    private fun saveLegacy(context: Context, file: File, displayName: String): Uri? {
        if (!file.exists() || !file.isFile || file.length() <= 0L) return null
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "SubGenius")
        if (!dir.exists() && !dir.mkdirs()) return null
        val out = File(dir, "$displayName.mp4")
        file.copyTo(out, overwrite = true)
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, out.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.DATA, out.absolutePath)
        }
        return context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
    }

    fun openVideo(context: Context, uri: Uri) {
        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            Toast.makeText(context, tr("تعذّر فتح الفيديو", "Could not open the video"), Toast.LENGTH_SHORT).show()
        }
    }
}
