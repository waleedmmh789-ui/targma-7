package com.waleed.subgenius.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import com.waleed.subgenius.engine.WorkKeeper

/** يشغّل خدمة الإبقاء (إشعار + منع النوم) طالما working = true، ويوقفها عند الانتهاء أو مغادرة الشاشة */
@Composable
fun KeepAliveWhile(working: Boolean, progress: Int, title: String) {
    val context = LocalContext.current.applicationContext
    LaunchedEffect(working) {
        if (working) WorkKeeper.start(context, title, progress) else WorkKeeper.stop(context)
    }
    LaunchedEffect(progress) {
        if (working) WorkKeeper.update(context, title, progress)
    }
    DisposableEffect(Unit) {
        onDispose { WorkKeeper.stop(context) }
    }
}
