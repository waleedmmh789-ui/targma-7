package com.waleed.subgenius.engine

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.waleed.subgenius.MainActivity
import com.waleed.subgenius.R
import com.waleed.subgenius.tr

/**
 * يُبقي التطبيق حياً أثناء المعالجة الطويلة (استخراج، دبلجة، حرق...) حتى لا يقتله النظام
 * عند الذهاب للخلفية أو إطفاء الشاشة، ويعرض إشعار تقدّم. لا ينفّذ العمل بنفسه؛ العمل يبقى في الشاشات.
 */
object WorkKeeper {
    @Volatile private var running = false
    @Volatile private var lastPercent = -2
    @Volatile private var lastTime = 0L

    fun start(context: Context, title: String, percent: Int = -1) {
        send(context, title, percent)
    }

    /** تحديث الإشعار (نحدّ المعدل حتى لا نغرق النظام) */
    fun update(context: Context, title: String, percent: Int) {
        val now = System.currentTimeMillis()
        if (percent == lastPercent) return
        if (percent < 100 && now - lastTime < 800) return
        send(context, title, percent)
    }

    fun stop(context: Context) {
        if (!running) return
        running = false
        runCatching { context.stopService(Intent(context, WorkKeeperService::class.java)) }
    }

    private fun send(context: Context, title: String, percent: Int) {
        lastPercent = percent
        lastTime = System.currentTimeMillis()
        val ok = runCatching {
            ContextCompat.startForegroundService(
                context,
                Intent(context, WorkKeeperService::class.java)
                    .putExtra(WorkKeeperService.EXTRA_TITLE, title)
                    .putExtra(WorkKeeperService.EXTRA_PERCENT, percent)
            )
        }.isSuccess
        if (ok) running = true
    }
}

class WorkKeeperService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val title = intent?.getStringExtra(EXTRA_TITLE) ?: getString(R.string.app_name)
        val percent = intent?.getIntExtra(EXTRA_PERCENT, -1) ?: -1
        val notification = buildNotification(title, percent)
        try {
            ServiceCompat.startForeground(this, NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } catch (e: Exception) {
            runCatching { startForeground(NOTIF_ID, notification) }
        }
        acquireWakeLock()
        return START_NOT_STICKY
    }

    private fun buildNotification(title: String, percent: Int): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, tr("المعالجة", "Processing"), NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle(title)
            .setContentText(if (percent >= 0) "$percent%" else tr("جارٍ المعالجة…", "Working…"))
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
        if (percent >= 0) b.setProgress(100, percent.coerceIn(0, 100), false) else b.setProgress(0, 0, true)
        return b.build()
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SubGenius:work").apply {
            setReferenceCounted(false)
            acquire(3 * 60 * 60 * 1000L) // حد أقصى 3 ساعات
        }
    }

    /** أندرويد 15: خدمات dataSync لها مهلة؛ نتوقف فوراً عند انتهائها */
    override fun onTimeout(startId: Int, fgsType: Int) {
        stopSelf()
    }

    override fun onDestroy() {
        runCatching { wakeLock?.takeIf { it.isHeld }?.release() }
        wakeLock = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_PERCENT = "percent"
        private const val CHANNEL_ID = "processing"
        private const val NOTIF_ID = 4101
    }
}
