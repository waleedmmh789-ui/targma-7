package com.waleed.subgenius.engine

import android.content.Context
import android.app.ActivityManager
import dev.ffmpegkit.whisper.Whisper
import dev.ffmpegkit.whisper.WhisperConfig
import dev.ffmpegkit.whisper.WhisperModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.coroutineContext

/** التعرف على الكلام بـ Whisper (أدق مع اللهجات العربية من Vosk) */
object WhisperSpeech {
    val languages = listOf(
        "ar" to "العربية", "en" to "English", "fr" to "Français", "es" to "Español", "de" to "Deutsch",
        "tr" to "Türkçe", "ru" to "Русский", "zh" to "中文", "ja" to "日本語", "el" to "Ελληνικά"
    )

    // Adaptive chunks: process every video in bounded pieces to avoid large WAV allocations
    // and native Whisper memory spikes, especially on older / low-RAM devices.
    private const val LOW_RAM_CHUNK_SEC = 15
    private const val VERY_LOW_MEMORY_CHUNK_SEC = 20
    private const val MID_MEMORY_CHUNK_SEC = 30
    private const val HIGH_MEMORY_CHUNK_SEC = 45

    private val lock = Mutex()
    private var cachedPath: String? = null
    private var cachedModel: WhisperModel? = null
    private val active = AtomicInteger(0)

    private suspend fun getModel(context: Context, path: String): WhisperModel = lock.withLock {
        val cur = cachedModel
        if (cur != null && cachedPath == path) return@withLock cur
        cur?.let { runCatching { Whisper.releaseModel(it) } }
        cachedModel = null; cachedPath = null
        val m = Whisper.loadModel(context.applicationContext, path)
        cachedModel = m; cachedPath = path
        m
    }

    /** يحرّر النموذج من الذاكرة (فقط إن لم تكن هناك معالجة جارية) */
    fun releaseModel() {
        if (active.get() == 0 && lock.tryLock()) {
            try {
                cachedModel?.let { runCatching { Whisper.releaseModel(it) } }
                cachedModel = null; cachedPath = null
            } finally { lock.unlock() }
        }
    }

    /**
     * pcmFile: صوت خام s16le 16kHz mono.
     * translateToEnglish: Whisper يترجم من الصوت مباشرة إلى الإنجليزية (الأدق للهجات).
     */
    suspend fun transcribe(
        context: Context, pcmFile: File, modelPath: String, language: String,
        translateToEnglish: Boolean, onProgress: (Int) -> Unit = {}
    ): Result<List<SpeechSegment>> = withContext(Dispatchers.Default) {
        active.incrementAndGet()
        var memoryFailure = false
        try {
            val model = getModel(context, modelPath)
            val total = pcmFile.length()
            if (total <= 0) return@withContext Result.success(emptyList())
            // PCM is stored on disk; only one bounded WAV chunk is created at a time.
            // Never send a whole short video to native Whisper: even a 4-minute WAV can
            // trigger a large native-memory spike on old devices.
            val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val lowRam = activityManager?.isLowRamDevice == true
            val memoryInfo = android.app.ActivityManager.MemoryInfo()
            activityManager?.getMemoryInfo(memoryInfo)
            val totalRamGb = memoryInfo.totalMem / (1024L * 1024L * 1024L)
            val chunkSec = when {
                lowRam -> LOW_RAM_CHUNK_SEC
                totalRamGb <= 3L -> VERY_LOW_MEMORY_CHUNK_SEC
                totalRamGb <= 4L -> MID_MEMORY_CHUNK_SEC
                else -> HIGH_MEMORY_CHUNK_SEC
            }
            val ranges = PcmUtils.splitRanges(pcmFile, total, chunkSec)
            // Keep native inference thread count conservative to avoid CPU/RAM pressure.
            val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
            val threads = if (lowRam || totalRamGb <= 3L) 1 else (cores / 2).coerceIn(2, 3)
            val out = mutableListOf<SpeechSegment>()

            ranges.forEachIndexed { i, (s, e) ->
                coroutineContext.ensureActive()
                if (!PcmUtils.isSilent(pcmFile, s, e)) {
                    val wav = File(context.cacheDir, "chunk_${System.currentTimeMillis()}_$i.wav")
                    try {
                        PcmUtils.writeWav(pcmFile, s, e, wav)
                        val r = Whisper.transcribe(
                            model, wav.absolutePath,
                            WhisperConfig(language = language, translate = translateToEnglish, threads = threads)
                        )
                        val offset = s * 1000 / PcmUtils.BYTES_PER_SEC
                        r.segments.forEach { seg ->
                            val t = clean(seg.text, language, translateToEnglish)
                            if (t.isNotEmpty()) out.add(SpeechSegment(t, offset + seg.startMs, offset + maxOf(seg.endMs, seg.startMs + 500)))
                        }
                    } finally { runCatching { wav.delete() } }
                }
                onProgress((((i + 1) * 100) / ranges.size).coerceIn(0, 99))
            }
            onProgress(100)
            Result.success(dedupe(out))
        } catch (e: CancellationException) {
            throw e
        } catch (e: OutOfMemoryError) {
            // Catch Java-side allocation failures so the UI can show a useful message.
            // This cannot recover from every native OOM, but it avoids turning a recoverable
            // allocation failure into an uncaught app-level error.
            memoryFailure = true
            Result.failure(IllegalStateException("الذاكرة غير كافية لهذا النموذج. اختر Whisper Base، وأغلق التطبيقات الأخرى ثم أعد المحاولة."))
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            active.decrementAndGet()
            if (memoryFailure) releaseModel()
        }
    }

    /** تنظيف محافظ: لا نحذف الكلمات اللاتينية المجاورة للعربية لأنها قد تكون أسماء أو مصطلحات صحيحة. */
    private fun clean(text: String, lang: String, translated: Boolean): String {
        return text.replace("\uFFFD", "")
            .replace(Regex("\\s{2,}"), " ")
            .trim()
    }

    /** يحذف التكرار المتتالي (علامة هلوسة شائعة في Whisper) */
    private fun dedupe(list: List<SpeechSegment>): List<SpeechSegment> {
        val out = mutableListOf<SpeechSegment>()
        for (s in list) {
            val n = out.size
            if (n >= 2 && out[n - 1].text == s.text && out[n - 2].text == s.text) continue
            out.add(s)
        }
        return out
    }
}
