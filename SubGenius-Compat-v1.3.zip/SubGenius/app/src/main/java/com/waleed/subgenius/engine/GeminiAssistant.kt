package com.waleed.subgenius.engine

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Gemini REST integration. API keys should be proxied through a trusted backend in production. */
object GeminiAssistant {
    private const val MODEL = "gemini-2.5-flash"
    private const val ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    suspend fun correctTranscript(apiKey: String, sourceLanguage: String, segments: List<SpeechSegment>, onProgress: (Int) -> Unit = {}): Result<List<SpeechSegment>> =
        processSegments(apiKey, sourceLanguage, "correct", segments, "", onProgress)

    suspend fun translateSegments(apiKey: String, sourceLanguage: String, targetLanguage: String, segments: List<SpeechSegment>, onProgress: (Int) -> Unit = {}): Result<List<SpeechSegment>> =
        processSegments(apiKey, sourceLanguage, "translate", segments, targetLanguage, onProgress)

    private suspend fun processSegments(
        apiKey: String, source: String, mode: String, segments: List<SpeechSegment>, target: String,
        onProgress: (Int) -> Unit
    ): Result<List<SpeechSegment>> = withContext(Dispatchers.IO) {
        try {
            require(apiKey.isNotBlank()) { "أدخل مفتاح Gemini API أولاً / Enter a Gemini API key first" }
            if (segments.isEmpty()) return@withContext Result.success(emptyList())
            val output = segments.toMutableList()
            val batches = segments.indices.toList().chunked(10)
            batches.forEachIndexed { batchIndex, indexes ->
                val input = JSONArray()
                indexes.forEach { i -> input.put(JSONObject().put("i", i).put("text", segments[i].text)) }
                val instruction = if (mode == "correct") {
                    "Correct speech-recognition mistakes in this transcript. Source language: $source. " +
                    "For Egyptian Arabic, preserve Egyptian dialect and colloquial wording; use context to fix likely misheard words. " +
                    "Do not translate, summarize, invent content, or change speaker intent. Keep each item separate. "
                } else {
                    "Translate each subtitle segment from $source to $target. Preserve meaning, tone, names, and dialogue context. " +
                    "Keep each item separate and concise for subtitles. Return only the translated text for each item. "
                }
                val prompt = instruction + "Return valid JSON only in this exact shape: {\"items\":[{\"i\":0,\"text\":\"...\"}]}. " +
                    "Return one item for every input index, preserve all indices, and do not add markdown. Input: " + input.toString()
                val response = request(apiKey.trim(), prompt)
                val parsedText = response.optJSONArray("items")
                    ?: throw IllegalStateException("Gemini response did not contain items")
                val byIndex = mutableMapOf<Int, String>()
                for (j in 0 until parsedText.length()) {
                    val item = parsedText.optJSONObject(j) ?: continue
                    val idx = item.optInt("i", -1)
                    val value = item.optString("text", "").trim()
                    if (idx in indexes && value.isNotBlank()) byIndex[idx] = value
                }
                indexes.forEach { i ->
                    val value = byIndex[i] ?: throw IllegalStateException("Gemini omitted segment $i")
                    output[i] = segments[i].copy(text = value)
                }
                onProgress(((batchIndex + 1) * 100) / batches.size)
            }
            Result.success(output)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    private fun request(apiKey: String, prompt: String): JSONObject {
        val url = URL("$ENDPOINT?key=${java.net.URLEncoder.encode(apiKey, "UTF-8")}")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        try {
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                .put("generationConfig", JSONObject().put("temperature", 0.1).put("responseMimeType", "application/json"))
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (status !in 200..299) {
                val message = runCatching { JSONObject(raw).optJSONObject("error")?.optString("message") }.getOrNull()
                throw IllegalStateException("Gemini HTTP $status: ${message ?: raw.take(300)}")
            }
            val envelope = JSONObject(raw)
            val text = envelope.optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text", "")
                ?.trim().orEmpty()
            if (text.isBlank()) throw IllegalStateException("Gemini returned an empty response")
            return JSONObject(text.removePrefix("```json").removePrefix("```").removeSuffix("```").trim())
        } finally {
            connection.disconnect()
        }
    }
}
