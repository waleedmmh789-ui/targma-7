package com.waleed.subgenius.engine

import com.waleed.subgenius.tr

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

data class WhisperModelInfo(
    val id: String, private val labelAr: String, private val labelEn: String, val fileName: String,
    val url: String, val size: String, val minBytes: Long
) {
    val label: String get() = tr(labelAr, labelEn)
}

object WhisperModelDownloader {
    private const val BASE = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/"

    /** الترتيب = الأفضلية: أول نموذج مُنزَّل هو المستعمل. المضغوط (q5_1) أسرع وأخف ذاكرة ودقته قريبة من الأصلي */
    val models = listOf(
        WhisperModelInfo("small-q5", "Small مضغوط — موصى به (سريع ودقيق)", "Small compressed — recommended (fast & accurate)", "ggml-small-q5_1.bin", BASE + "ggml-small-q5_1.bin", "~181MB", 150_000_000L),
        WhisperModelInfo("small", "Small — دقة أعلى وأبطأ", "Small — higher accuracy, slower", "ggml-small.bin", BASE + "ggml-small.bin", "~466MB", 400_000_000L),
        WhisperModelInfo("base-q5", "Base مضغوط — الأخف للهواتف القديمة", "Base compressed — lightest for older phones", "ggml-base-q5_1.bin", BASE + "ggml-base-q5_1.bin", "~57MB", 50_000_000L),
        WhisperModelInfo("base", "Base — أسرع وأقل دقة", "Base — faster, less accurate", "ggml-base.bin", BASE + "ggml-base.bin", "~142MB", 120_000_000L)
    )

    private fun dir(context: Context) = File(context.filesDir, "whisper").apply { mkdirs() }
    fun file(context: Context, m: WhisperModelInfo) = File(dir(context), m.fileName)
    fun isDownloaded(context: Context, m: WhisperModelInfo) =
        file(context, m).let { it.exists() && it.length() >= m.minBytes }

    fun bestModelPath(context: Context): String? =
        models.firstOrNull { isDownloaded(context, it) }?.let { file(context, it).absolutePath }

    suspend fun download(context: Context, m: WhisperModelInfo, onProgress: (Int) -> Unit): Result<Unit> =
        withContext(Dispatchers.IO) {
            val part = File(dir(context), m.fileName + ".part")
            var conn: HttpURLConnection? = null
            try {
                val connection = URL(m.url).openConnection() as HttpURLConnection
                conn = connection
                connection.connectTimeout = 20000; connection.readTimeout = 30000
                connection.connect()
                if (connection.responseCode != 200) throw Exception(tr("HTTP ${connection.responseCode} — تحقق من رابط النموذج", "HTTP ${connection.responseCode} — check the model link"))
                val total = connection.contentLengthLong
                if (total > 0 && context.filesDir.usableSpace < total + 50_000_000L)
                    throw Exception(tr("المساحة غير كافية", "Not enough storage space"))
                var done = 0L
                var last = -1
                connection.inputStream.use { input ->
                    FileOutputStream(part).use { out ->
                        val buf = ByteArray(65536); var n: Int
                        while (input.read(buf).also { n = it } != -1) {
                            out.write(buf, 0, n); done += n
                            if (total > 0) {
                                val pct = ((done * 100) / total).toInt().coerceIn(0, 99)
                                if (pct != last) { last = pct; onProgress(pct) }
                            }
                        }
                    }
                }
                if (part.length() < m.minBytes) throw Exception(tr("الملف ناقص، أعد المحاولة", "Incomplete file, try again"))
                val target = file(context, m)
                if (target.exists()) target.delete()
                if (!part.renameTo(target)) throw Exception(tr("تعذّر حفظ النموذج", "Could not save the model"))
                onProgress(100)
                Result.success(Unit)
            } catch (e: CancellationException) {
                runCatching { part.delete() }
                throw e
            } catch (e: Exception) {
                runCatching { part.delete() }
                Result.failure(e)
            } finally {
                conn?.disconnect()
            }
        }
}
