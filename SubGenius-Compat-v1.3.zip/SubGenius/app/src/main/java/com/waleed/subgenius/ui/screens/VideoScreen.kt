package com.waleed.subgenius.ui.screens

import com.waleed.subgenius.ui.components.KeepAliveWhile
import com.waleed.subgenius.tr

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.waleed.subgenius.engine.CompressionLevel
import com.waleed.subgenius.engine.FFmpegHelper
import com.waleed.subgenius.ui.AppViewModel
import com.waleed.subgenius.ui.components.TopBar
import com.waleed.subgenius.ui.theme.BgDark
import com.waleed.subgenius.ui.theme.ErrRed
import com.waleed.subgenius.ui.theme.Primary
import com.waleed.subgenius.ui.theme.Secondary
import com.waleed.subgenius.ui.theme.SurfaceDark
import com.waleed.subgenius.ui.theme.TextGray
import com.waleed.subgenius.ui.theme.TextWhite
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun VideoScreen(
    appViewModel: AppViewModel,
    onBack: () -> Unit,
    onExtract: () -> Unit,
    onTranslate: () -> Unit,
    onCustomize: () -> Unit,
    onDub: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val state by appViewModel.state.collectAsState()
    var level by remember { mutableStateOf(CompressionLevel.MEDIUM) }
    var compressing by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    KeepAliveWhile(compressing, progress, com.waleed.subgenius.tr("ضغط الفيديو","Compressing video"))
    var status by remember { mutableStateOf<String?>(null) }
    val file = state.videoFile

    Column(Modifier.fillMaxSize().background(BgDark).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        TopBar(tr("معاينة الفيديو", "Video preview"), onBack)
        Spacer(Modifier.height(8.dp))
        when {
            state.loading -> Box(Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            file == null -> Text(tr("تعذّر فتح الفيديو. ارجع واختر فيديو آخر.", "Could not open the video. Go back and pick another one."), color = ErrRed)
            else -> {
                VideoPlayer(file)
                Spacer(Modifier.height(16.dp))
                Text(tr("مستوى الضغط:", "Compression level:"), color = TextGray, fontSize = 12.sp)
                CompressionLevel.entries.forEach { l ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = level == l, onClick = { level = l }, enabled = !compressing)
                        Text(l.label, color = TextWhite, fontSize = 14.sp)
                    }
                }
                if (compressing) {
                    LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth(), color = Primary)
                    Text(tr("جارٍ الضغط: $progress%", "Compressing: $progress%"), color = TextGray, fontSize = 12.sp)
                } else {
                    Button(
                        onClick = {
                            scope.launch {
                                compressing = true; progress = 0; status = null
                                val r = FFmpegHelper.compressVideo(context, file, level) { progress = it }
                                compressing = false
                                r.onSuccess { appViewModel.setVideoFile(it, level); status = tr("تم ✅", "Done ✅") }
                                    .onFailure { status = tr("فشل: ${it.message}", "Failed: ${it.message}") }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Secondary)
                    ) { Text(tr("تطبيق", "Apply")) }
                }
                status?.let { Text(it, color = Secondary, fontSize = 12.sp) }
                Spacer(Modifier.height(16.dp))
                ActionButton(Icons.Filled.Mic, tr("استخراج النص", "Extract text"), tr("تحويل الكلام إلى نص", "Convert speech to text"), onExtract)
                Spacer(Modifier.height(12.dp))
                ActionButton(Icons.Filled.Translate, tr("ترجمة", "Translate"), tr("ترجمة النص المستخرج", "Translate the extracted text"), onTranslate)
                Spacer(Modifier.height(12.dp))
                ActionButton(Icons.Filled.LocalFireDepartment, tr("حرق الترجمة", "Burn subtitles"), tr("دمج الترجمة داخل الفيديو", "Merge subtitles into the video"), onCustomize)
                Spacer(Modifier.height(12.dp))
                ActionButton(Icons.Filled.RecordVoiceOver, tr("دبلجة صوتية", "Voice dubbing"), tr("نطق النص بصوت من هاتفك ودمجه في الفيديو", "Speak the text with a phone voice and mix it into the video"), onDub)
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun VideoPlayer(file: File) {
    val context = LocalContext.current
    val exo = remember(file) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
            prepare()
            playWhenReady = false
        }
    }
    DisposableEffect(exo) { onDispose { exo.release() } }
    Card(Modifier.fillMaxWidth().aspectRatio(16f / 9f), shape = RoundedCornerShape(16.dp)) {
        AndroidView(factory = { ctx -> PlayerView(ctx).apply { player = exo } }, modifier = Modifier.fillMaxSize())
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ActionButton(icon: ImageVector, title: String, desc: String, onClick: () -> Unit) {
    Card(
        onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).background(Primary.copy(alpha = 0.2f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = Primary)
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = TextWhite)
                Text(desc, fontSize = 12.sp, color = TextGray)
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = TextGray)
        }
    }
}
