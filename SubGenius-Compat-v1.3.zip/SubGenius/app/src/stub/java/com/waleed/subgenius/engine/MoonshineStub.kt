package com.waleed.subgenius.engine

import android.content.Context
import java.io.File

/**
 * نسخة بديلة (stub): محرك Moonshine غير مفعّل في هذا البناء حتى لا يتوقف البناء بسبب مكتبة تجريبية.
 * لتفعيله: ابنِ بـ  -PwithMoonshine=true  (أو شغّل الـ workflow مع with_moonshine = true).
 */
object MoonshineModelDownloader {
    const val AVAILABLE = false
    const val MODEL_DIR = "sherpa-moonshine-ar"
    fun modelDir(context: Context) = File(context.filesDir, MODEL_DIR)
    fun isDownloaded(context: Context): Boolean = false
    suspend fun download(context: Context, onProgress: (Int) -> Unit = {}): Result<String> =
        Result.failure(UnsupportedOperationException("Moonshine غير مفعّل في هذا الإصدار"))
}

object MoonshineSpeech {
    const val AVAILABLE = false
    suspend fun transcribe(pcmFile: File, modelDir: String, onProgress: (Int) -> Unit = {}): Result<List<SpeechSegment>> =
        Result.failure(UnsupportedOperationException("Moonshine غير مفعّل في هذا الإصدار"))
}
