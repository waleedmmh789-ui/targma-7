# ===== قواعد R8 لمكتبات JNI (التطبيق يعتمد عليها بالاسم من كود native) =====
# أسماء دوال native
-keepclasseswithmembernames,includedescriptorclasses class * { native <methods>; }

# FFmpegKit: كود native يستدعي كلاساتها بالاسم (callbacks)
-keep class com.arthenica.** { *; }
# Whisper (whisper.cpp)
-keep class dev.ffmpegkit.** { *; }
# Vosk + JNA
-keep class org.vosk.** { *; }
-keep class com.alphacephei.vosk.** { *; }
-keep class com.sun.jna.** { *; }
-dontwarn com.sun.jna.**
# Sherpa-ONNX / ONNX Runtime (عند تفعيل Moonshine)
-keep class com.k2fsa.sherpa.onnx.** { *; }
-keep class ai.onnxruntime.** { *; }
-dontwarn org.apache.commons.compress.**
-dontwarn org.tukaani.xz.**
-dontwarn com.github.luben.zstd.**
-dontwarn org.brotli.**

# Room
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

# أسطر المصدر في تقرير الانهيار (مع mapping.txt يمكن فك التشفير)
-keepattributes SourceFile,LineNumberTable,*Annotation*,Signature,InnerClasses,EnclosingMethod
-renamesourcefileattribute SourceFile

# لا نوقف البناء بسبب كلاسات اختيارية مفقودة في مكتبات خارجية
-ignorewarnings
