plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

// رقم التشغيل في GitHub Actions: يزيد تلقائياً مع كل Run فيتغير رقم الإصدار دائماً
val ciRun: Int? = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull()
val baseVersion = "1.3"
// محرك Moonshine (Sherpa-ONNX) تجريبي ومن مستودع طرف ثالث: غير مفعّل افتراضياً. فعّله بـ -PwithMoonshine=true
val withMoonshine = (project.findProperty("withMoonshine") as String?) == "true"

android {
    namespace = "com.waleed.subgenius"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.waleed.subgenius.app"
        // 24 = أندرويد 7.0: أقل إصدار تدعمه مكتبة FFmpeg
        minSdk = 24
        targetSdk = 36
        // versionCode = دقائق منذ 1970: يزيد مع كل بناء (GitHub أو محلي) فيمكن تثبيت أي بناء فوق السابق دون "downgrade"
        versionCode = (System.currentTimeMillis() / 60000L).toInt()
        versionName = "$baseVersion.${ciRun ?: 0}"  // مثال: 1.3.23 (الرقم الأخير = رقم التشغيل في GitHub)
        // FFmpeg وWhisper المُصانتان تنشران arm64-v8a فقط (لا يوجد 32-bit)
        ndk { abiFilters += "arm64-v8a" }
    }

    signingConfigs {
        // مفتاح ثابت داخل المشروع: يجعل كل الإصدارات موقّعة بنفس التوقيع فتتحدّث فوق بعضها بدل "تعارض التوقيع".
        // للتثبيت المباشر فقط. للنشر على Google Play أضف Secrets (KEYSTORE_BASE64...) فيُستعمل مفتاحك.
        create("ci") {
            storeFile = file("ci-signing.p12")
            storePassword = "subgenius-ci"
            keyAlias = "subgenius"
            keyPassword = "subgenius-ci"
            storeType = "pkcs12"
        }
        create("release") {
            val keystorePath = System.getenv("KEYSTORE_FILE")
            if (keystorePath != null && file(keystorePath).exists()) {
                storeFile = file(keystorePath)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("ci")
        }
        release {
            // تصغير كود Java/Kotlin وإزالة الموارد غير المستخدمة (لتقليل حجم AAB/APK).
            // قواعد الحماية لمكتبات JNI في proguard-rules.pro. إن ظهر انهيار في release فقط جرّب release-safe.
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = if (signingConfigs.getByName("release").storeFile != null)
                signingConfigs.getByName("release") else signingConfigs.getByName("ci")
        }
        // نسخة بنفس التوقيع بدون R8: للتحقق إن كان R8 هو سبب أي انهيار
        create("releaseSafe") {
            initWith(getByName("release"))
            isMinifyEnabled = false
            isShrinkResources = false
            matchingFallbacks += listOf("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }

    // لا نقسّم اللغات في الـ AAB حتى تبقى الواجهة عربي/إنجليزي تعمل على كل الأجهزة
    bundle { language { enableSplit = false } }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            pickFirsts += "META-INF/versions/9/previous-compilation-data.bin"
        }
        // whisper-android وffmpeg-kit (وغيرهما) تضمّان نفس المكتبات المشتركة.
        // نختار "أول نسخة" ونتجاهل المكرر حتى لا يتوقف البناء بخطأ "2 files found with path".
        jniLibs {
            pickFirsts += "**/libc++_shared.so"
            pickFirsts += "**/libomp.so"
            pickFirsts += "**/libjnidispatch.so"
        }
    }

    // Moonshine الحقيقي أو النسخة البديلة (stub) حسب الخيار
    sourceSets["main"].java.srcDir(if (withMoonshine) "src/moonshine/java" else "src/stub/java")

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.8.4")
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // FFmpeg (نسخة مُصانة بعد إيقاف المشروع الأصلي). إن فشل التحميل: ضع ملف .aar في app/libs
    implementation("dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.7")
    implementation("com.arthenica:smart-exception-java:0.2.1")
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.aar"))))

    // Vosk 0.3.75 يدعم صفحات الذاكرة 16KB (مطلوب في Google Play)
    implementation("com.alphacephei:vosk-android:0.3.75")
    // Whisper (whisper.cpp) للتعرف على اللهجات — إن لم يُحمَّل 1.0.0 جرّب 0.1.2
    implementation("dev.ffmpegkit-maintained:whisper-android:1.0.0")
    implementation("net.java.dev.jna:jna:5.17.0@aar")
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("androidx.media3:media3-exoplayer:1.5.0")
    implementation("androidx.media3:media3-ui:1.5.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.9.0")

    if (withMoonshine) {
        // Sherpa-ONNX من مستودع XDcobra (طرف ثالث). يضيف مكتبات native إضافية فيزيد الحجم.
        implementation("com.xdcobra.sherpa:sherpa-onnx:1.12.24")
        implementation("org.apache.commons:commons-compress:1.27.1")
    }
}
