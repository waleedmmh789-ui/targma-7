# عبقري الترجمة والدبلجة (SubGenius)

## البناء على GitHub (APK + AAB)
1. ضع محتوى هذا المجلد في **جذر** المستودع (يجب أن يظهر `app/` و`build.gradle.kts` و`.github/` مباشرة). احذف أي workflow قديم من `.github/workflows`.
2. Actions ← **Build SubGenius** ← Run workflow (أو ادفع إلى `main`).
3. من Artifacts ← **SubGenius-<الإصدار>**: ملفات `SubGenius-1.3.N-debug.apk` و`-release.apk` (مع R8) و`-release-safe-noR8.apk` و`-release.aab` (تحمل الوسم `-TESTKEY` إن لم تضف مفتاح نشر) و`mapping-1.3.N.txt`.
4. لإصدار على Releases: ادفع وسماً مثل `v1.3.0`.

### رقم الإصدار يتغير مع كل Run
- `versionCode` = دقائق منذ 1970 (يزيد مع كل بناء، محلياً أو على GitHub، فلا يحدث رفض «downgrade») و`versionName = 1.3.<رقم التشغيل>` (مثل 1.3.23). يظهر في شاشة «حول التطبيق».
- لتغيير الرقم الأساسي عدّل `baseVersion` في `app/build.gradle.kts`.

### Gradle داخل المشروع
- الملفات `gradlew` و`gradlew.bat` و`gradle/wrapper/gradle-wrapper.properties` موجودة. ملف `gradle-wrapper.jar` يُنزَّل تلقائياً عند أول تشغيل لـ `./gradlew`.
- في أول Run على GitHub يُنشئ الـ workflow الملف الرسمي ويحفظه في المستودع تلقائياً (commit باسم github-actions). لا يوقف البناء إن فشلت هذه الخطوة.

### تعارض المكتبات (libc++_shared.so)
`whisper-android` و`ffmpeg-kit` يضمّان نفس المكتبة المشتركة. حُلَّ بـ `pickFirsts` في `app/build.gradle.kts` (قسم `packaging`)، فيختار البناء أول نسخة ولا يتوقف. لا تحذف هذه الأسطر.

### التوقيع (مهم)
- بدون أسرار: يُوقَّع كل شيء بمفتاح اختبار **علني** `app/ci-signing.p12` (الموجود في المستودع)، وتحمل الملفات الوسم `-TESTKEY` وتظهر تحذيراً في الـ workflow. **لا توزّع هذه الملفات على الناس ولا ترفعها إلى Google Play**، لأن أي شخص يملك المفتاح يستطيع توقيع تطبيق ينتحل تطبيقك.
- للنشر: شغّل `bash scripts/make_keystore.sh` مرة واحدة (Termux: `pkg install openjdk-17 openssl-tool`)، وأضف الأسرار الأربعة في GitHub: `KEYSTORE_BASE64` و`KEYSTORE_PASSWORD` و`KEY_ALIAS` و`KEY_PASSWORD`. احتفظ بنسخة احتياطية من `release.keystore` وكلمة المرور؛ بدونهما لا تستطيع تحديث التطبيق. فعّل Play App Signing عند الرفع.

## تخفيف الحجم (R8) والنسخة الآمنة
- نسخة release تُبنى مع **R8 وshrinkResources** لتقليل حجم الكود والموارد، وفيها قواعد حماية لمكتبات JNI في `app/proguard-rules.pro`.
- أي تصغير قد يكسر مكتبات تستدعيها كود native بالاسم. لذلك يبني الـ workflow أيضاً `SubGenius-<الإصدار>-release-safe-noR8.apk` بنفس التوقيع وبدون R8. **جرّب نسخة release أولاً؛ إن انهارت وحدها فالسبب R8، فاستعمل النسخة الآمنة وأرسل لي نص الخطأ.**
- ملف `mapping-<الإصدار>.txt` يفك تشفير الأخطاء؛ ارفعه مع الـ AAB في Play Console.
- R8 يقلل كود Java/Kotlin فقط. الحجم الأكبر في مكتبات native (FFmpeg وWhisper وVosk). راجع حجم التنزيل الفعلي في Play Console ← App Bundle Explorer.

## محرك Moonshine (تجريبي، غير مفعّل افتراضياً)
- يعتمد على Sherpa-ONNX من مستودع XDcobra (طرف ثالث) ويضيف مكتبات native فيزيد الحجم، لذلك لا يدخل البناء الافتراضي (النسخة البديلة `src/stub`).
- للتفعيل: Actions ← Run workflow ← **with_moonshine = true**، أو محلياً `./gradlew assembleRelease -PwithMoonshine=true`. يظهر خيار «Moonshine — عربي» في شاشة استخراج النص.
- لم أتحقق أن واجهة Sherpa 1.12.24 تدعم نموذج Moonshine v2 العربي المنزَّل؛ إن فشل البناء أو التشغيل بهذا الخيار فلا يؤثر على البناء الافتراضي.

## معالجة الخلفية (خدمة أمامية)
أثناء الاستخراج والترجمة والدبلجة والحرق والضغط يعمل إشعار تقدّم وخدمة أمامية (`dataSync`) مع منع نوم المعالج (حد أقصى 3 ساعات)، فلا يقتل النظام التطبيق عند إطفاء الشاشة أو الذهاب للخلفية. التطبيق يطلب إذن الإشعارات على أندرويد 13+ (إن رفضته تستمر المعالجة دون إشعار ظاهر). العمل نفسه ما زال داخل الشاشة: مغادرة الشاشة تلغيه. راجع `PLAY_DATA_SAFETY_AR.txt` لنموذج الخدمات الأمامية في Play Console.

## الخط العربي
خط DejaVu Sans مضمّن احتياطياً في `assets/fonts` ويُستعمل عند غياب خط النظام، فلا تظهر مربعات في الترجمة المحروقة. إشعارات التراخيص في `THIRD_PARTY_NOTICES.txt`.

## الأجهزة المدعومة
- أندرويد 7.0 (API 24) فأحدث، بمعالج 64 بت (arm64-v8a).
- لا يدعم الهواتف ذات 32 بت فقط، لأن مكتبتي FFmpeg وWhisper المُصانتين تنشران arm64 فقط (لا توجد نسخة 32 بت منهما).
- حفظ المعرض يعمل من أندرويد 7: على 7 إلى 9 يطلب التطبيق إذن التخزين، ومن 10 لا يحتاج إذناً.
- للهواتف القديمة أو محدودة الذاكرة: نموذج Whisper «Base مضغوط» (~57MB) أو محرك Vosk.

## قبل النشر في Google Play
1. غيّر `com.waleed.subgenius.app` إلى اسم حزمتك قبل أول رفع (لا يمكن تغييره لاحقاً).
2. صفحات 16KB: خطوة «Check 16KB» في الـ workflow تطبع النتيجة؛ أي `FAIL` يعني مكتبة سترفضها Play (راجع `whisper-android`).
3. تحقق من روابط النماذج في `WhisperModelDownloader.kt` و`VoskModelDownloader.kt` إن ظهر HTTP 404.
4. إن لم يُحمَّل `whisper-android:1.0.0` جرّب `0.1.2`.
5. نص سياسة الخصوصية في `docs/privacy-policy.html` ورابطها على Google Sites داخل شاشة «حول التطبيق».
6. التطبيق مجاني: لا فوترة ولا اشتراكات. الخط العربي: خط النظام، ولخط محدد ضع ملف .ttf في `app/src/main/assets/fonts/`.

## تقرير الانهيار
إن انهار التطبيق يظهر في التشغيل التالي حوار فيه نص الخطأ مع زر «نسخ النص» لإرساله للمطوّر.

## Gemini AI integration

The Translate screen now includes an optional Gemini AI engine. Enter a Gemini API key in the screen to translate subtitle segments or review a previously extracted transcript. Transcript review is intended to correct likely recognition errors while preserving Egyptian Arabic dialect and segment timing.

- The API key is kept only in the current screen state and is not written to SharedPreferences or source files.
- Do not commit API keys to GitHub. For a public production app, proxy Gemini requests through a trusted backend so the key is not exposed in the APK.
- Gemini processing requires internet access and may incur API charges or be subject to quota limits. Audio/text content submitted for processing is sent to Google.
- Always review the corrected transcript before exporting subtitles; AI correction can still make mistakes.
