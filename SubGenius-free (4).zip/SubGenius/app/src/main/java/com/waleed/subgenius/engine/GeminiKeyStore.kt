package com.waleed.subgenius.engine

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * يحفظ مفتاح Gemini على الجهاز بشكل دائم ومشفّر (AES-GCM بمفتاح داخل Android Keystore).
 * إن تعذّر التشفير على جهاز ما يُحفظ في مساحة التطبيق الخاصة (غير مشمولة بالنسخ الاحتياطي).
 */
object GeminiKeyStore {
    private const val PREFS = "gemini_prefs"
    private const val K_ENC = "key_enc"
    private const val K_PLAIN = "key_plain"
    private const val K_MODEL = "model"
    private const val ALIAS = "subgenius_gemini_key"

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun saveKey(context: Context, key: String) {
        val p = prefs(context).edit()
        val k = key.trim()
        if (k.isEmpty()) { p.remove(K_ENC).remove(K_PLAIN).apply(); return }
        try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, secretKey())
            val blob = cipher.iv + cipher.doFinal(k.toByteArray(Charsets.UTF_8))
            p.putString(K_ENC, Base64.encodeToString(blob, Base64.NO_WRAP)).remove(K_PLAIN)
        } catch (e: Exception) {
            p.putString(K_PLAIN, k).remove(K_ENC)
        }
        p.apply()
    }

    fun loadKey(context: Context): String {
        val p = prefs(context)
        p.getString(K_ENC, null)?.let { enc ->
            try {
                val blob = Base64.decode(enc, Base64.NO_WRAP)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, blob.copyOfRange(0, 12)))
                return String(cipher.doFinal(blob.copyOfRange(12, blob.size)), Charsets.UTF_8)
            } catch (e: Exception) { return "" }
        }
        return p.getString(K_PLAIN, "") ?: ""
    }

    /** "auto" = يختار التطبيق الأحدث المتاح تلقائياً */
    fun loadModel(context: Context): String = prefs(context).getString(K_MODEL, "auto") ?: "auto"
    fun saveModel(context: Context, model: String) { prefs(context).edit().putString(K_MODEL, model).apply() }
}
