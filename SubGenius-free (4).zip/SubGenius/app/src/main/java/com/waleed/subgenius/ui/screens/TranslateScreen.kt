package com.waleed.subgenius.ui.screens

import com.waleed.subgenius.tr

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.waleed.subgenius.engine.OnlineTranslator
import com.waleed.subgenius.engine.GeminiAssistant
import com.waleed.subgenius.engine.TranslatorHelper
import com.waleed.subgenius.ui.AppViewModel
import com.waleed.subgenius.ui.components.TopBar
import com.waleed.subgenius.ui.theme.BgDark
import com.waleed.subgenius.ui.theme.ErrRed
import com.waleed.subgenius.ui.theme.Secondary
import com.waleed.subgenius.ui.theme.SurfaceDark
import com.waleed.subgenius.ui.theme.TextGray
import com.waleed.subgenius.ui.theme.TextWhite
import com.waleed.subgenius.ui.theme.WarnYellow
import android.content.Intent
import android.net.Uri
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalClipboardManager
import com.waleed.subgenius.engine.GeminiKeyStore
import kotlinx.coroutines.launch

private val langs = listOf(
    "ar" to "العربية", "en" to "English", "fr" to "Français", "es" to "Español", "de" to "Deutsch",
    "tr" to "Türkçe", "ru" to "Русский", "zh" to "中文", "ja" to "日本語", "el" to "Ελληνικά"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TranslateScreen(appViewModel: AppViewModel, onBack: () -> Unit, onDone: () -> Unit, onEdit: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val state by appViewModel.state.collectAsState()
    var source by remember { mutableStateOf(state.sourceLang) }
    var target by remember {
        mutableStateOf(if (state.targetLang == state.sourceLang) (if (state.sourceLang == "ar") "en" else "ar") else state.targetLang)
    }
    var engine by remember { mutableStateOf("online") }
    var geminiKey by remember { mutableStateOf(GeminiKeyStore.loadKey(context)) }
    var geminiModels by remember { mutableStateOf<List<String>>(emptyList()) }
    var geminiModel by remember { mutableStateOf(GeminiKeyStore.loadModel(context)) }
    var modelMenu by remember { mutableStateOf(false) }
    var keyStatus by remember { mutableStateOf<String?>(null) }
    var showGuide by remember { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current
    fun openStudio() {
        try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }
    fun saveKey(k: String) { geminiKey = k.trim(); GeminiKeyStore.saveKey(context, geminiKey); keyStatus = null }
    fun loadModels() {
        scope.launch {
            keyStatus = tr("جارٍ فحص المفتاح…", "Checking the key…")
            GeminiAssistant.listModels(geminiKey)
                .onSuccess {
                    geminiModels = it
                    keyStatus = tr("✅ المفتاح صالح — ${it.size} نموذج متاح", "✅ Key is valid — ${it.size} models available")
                }
                .onFailure { keyStatus = "❌ " + (it.message ?: "error") }
        }
    }
    LaunchedEffect(engine) { if (engine == "gemini" && geminiKey.isNotBlank() && geminiModels.isEmpty()) loadModels() }

    if (showGuide) {
        AlertDialog(
            onDismissRequest = { showGuide = false },
            title = { Text(tr("كيف أحصل على مفتاح Gemini؟", "How to get a Gemini API key?")) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(tr("1) افتح Google AI Studio (aistudio.google.com/apikey) وسجّل الدخول بحساب Google.", "1) Open Google AI Studio (aistudio.google.com/apikey) and sign in with your Google account."), fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(tr("2) اضغط «Create API key» (إنشاء مفتاح API) ثم اختر مشروعاً جديداً أو موجوداً.", "2) Tap \"Create API key\", then choose a new or existing project."), fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(tr("3) انسخ المفتاح (يبدأ عادةً بـ AIza).", "3) Copy the key (it usually starts with AIza)."), fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(tr("4) ارجع إلى التطبيق والصقه في خانة المفتاح (أو اضغط «لصق من الحافظة»). يُحفظ مشفّراً على جهازك ولا تحتاج لإدخاله مرة أخرى.", "4) Come back and paste it into the key field (or tap \"Paste from clipboard\"). It is saved encrypted on your device, so you won't need to enter it again."), fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(tr("5) اضغط «اختبار المفتاح» لتحميل نماذج Gemini المتاحة لمفتاحك.", "5) Tap \"Test key\" to load the Gemini models available for your key."), fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    Text(tr("ملاحظات: المفتاح مجاني ضمن حدود Google (قد تختلف حسب النموذج). مفتاح واحد يعمل مع كل نماذج Gemini المتاحة لحسابك. لا تشاركه مع أحد. النص المستخرج يُرسل إلى Google عند الاستخدام.", "Notes: the key is free within Google's limits (these vary by model). One key works with every Gemini model available to your account. Don't share it. The extracted text is sent to Google when you use it."), fontSize = 12.sp, color = TextGray)
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = { openStudio() }, modifier = Modifier.fillMaxWidth()) { Text(tr("فتح Google AI Studio", "Open Google AI Studio")) }
                    OutlinedButton(
                        onClick = { clipboard.getText()?.text?.let { saveKey(it); showGuide = false } },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(tr("لصق المفتاح من الحافظة", "Paste key from clipboard")) }
                }
            },
            confirmButton = { TextButton(onClick = { showGuide = false }) { Text(tr("تم", "Done")) } }
        )
    }
    var lingvaUrl by remember { mutableStateOf(OnlineTranslator.getCustomLingva(context)) }
    var working by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }
    var notice by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().background(BgDark).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        TopBar(tr("ترجمة النص", "Translate text"), onBack)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            LangDropdown(tr("من", "From"), source, Modifier.weight(1f)) { source = it }
            LangDropdown(tr("إلى", "To"), target, Modifier.weight(1f)) { target = it }
        }
        Spacer(Modifier.height(12.dp))
        Text(tr("محرك الترجمة:", "Translation engine:"), color = TextGray, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = engine == "online", onClick = { engine = "online" }, label = { Text(tr("أونلاين مجاني", "Free online")) }, enabled = !working)
            FilterChip(selected = engine == "gemini", onClick = { engine = "gemini"; if (geminiKey.isBlank()) showGuide = true }, label = { Text("Gemini AI") }, enabled = !working)
            FilterChip(selected = engine == "offline", onClick = { engine = "offline" }, label = { Text(tr("بدون إنترنت", "Offline")) }, enabled = !working)
        }
        if (engine == "online") {
            Text(
                tr("يُرسل النص إلى خوادم Lingva ثم MyMemory المجانية. قد تتوقف أو تُحدّ، وعندها تُستخدم الترجمة دون إنترنت تلقائياً.", "The text is sent to the free Lingva then MyMemory servers. They may go down or be rate-limited, in which case offline translation is used automatically."),
                color = TextGray, fontSize = 11.sp
            )
            OutlinedTextField(
                value = lingvaUrl,
                onValueChange = { lingvaUrl = it; OnlineTranslator.setCustomLingva(context, it) },
                label = { Text(tr("خادم Lingva خاص (اختياري، https://...)", "Custom Lingva server (optional, https://...)")) },
                singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = !working
            )
        }
        if (engine == "gemini") {
            OutlinedTextField(
                value = geminiKey,
                onValueChange = { saveKey(it) },
                label = { Text(tr("مفتاح Gemini API", "Gemini API key")) },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                enabled = !working
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { clipboard.getText()?.text?.let { saveKey(it) } }, modifier = Modifier.weight(1f), enabled = !working) {
                    Text(tr("لصق من الحافظة", "Paste from clipboard"), fontSize = 12.sp)
                }
                OutlinedButton(onClick = { showGuide = true }, modifier = Modifier.weight(1f), enabled = !working) {
                    Text(tr("كيف أحصل على مفتاح؟", "How to get a key?"), fontSize = 12.sp)
                }
            }
            OutlinedButton(onClick = { loadModels() }, enabled = !working && geminiKey.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                Text(tr("اختبار المفتاح وتحميل النماذج", "Test key & load models"))
            }
            keyStatus?.let { Text(it, color = if (it.startsWith("✅")) Secondary else WarnYellow, fontSize = 12.sp) }

            Text(tr("النموذج:", "Model:"), color = TextGray, fontSize = 12.sp)
            Box {
                OutlinedButton(onClick = { modelMenu = true }, modifier = Modifier.fillMaxWidth(), enabled = !working) {
                    Text(if (geminiModel == "auto") tr("تلقائي (الأحدث المتاح لمفتاحك)", "Auto (newest available for your key)") else geminiModel, color = TextWhite)
                }
                DropdownMenu(expanded = modelMenu, onDismissRequest = { modelMenu = false }) {
                    DropdownMenuItem(
                        text = { Text(tr("تلقائي (الأحدث المتاح لمفتاحك)", "Auto (newest available for your key)")) },
                        onClick = { geminiModel = "auto"; GeminiKeyStore.saveModel(context, "auto"); modelMenu = false }
                    )
                    geminiModels.forEach { m ->
                        DropdownMenuItem(text = { Text(m) }, onClick = { geminiModel = m; GeminiKeyStore.saveModel(context, m); modelMenu = false })
                    }
                }
            }
            Text(
                tr("أي مفتاح صالح يعمل مع كل نماذج Gemini المتاحة له. إن لم يتوفر النموذج أو نفدت حصته يجرّب التطبيق نموذجاً آخر تلقائياً.",
                   "Any valid key works with every Gemini model available to it. If a model is unavailable or out of quota, the app automatically tries another one."),
                color = TextGray, fontSize = 11.sp
            )
            Text(
                tr("يُحفظ المفتاح مشفّراً على جهازك فقط ولا يُرسل إلا إلى Google. النصوص تُرسل إلى Google لمعالجتها.",
                   "The key is stored encrypted on your device only and is sent only to Google. The texts are sent to Google for processing."),
                color = WarnYellow, fontSize = 11.sp
            )
            OutlinedButton(
                onClick = {
                    scope.launch {
                        error = null; notice = null; working = true; progress = 0
                        val r = GeminiAssistant.correctTranscript(geminiKey, geminiModel, source, state.originalSegments) { progress = it }
                        working = false
                        r.onSuccess {
                            appViewModel.setOriginalSegments(it, source)
                            notice = tr("تمت مراجعة النص بنموذج ${GeminiAssistant.lastModelUsed}. راجع النتيجة قبل اعتمادها.", "Transcript reviewed with ${GeminiAssistant.lastModelUsed}. Check the result before using it.")
                        }.onFailure { error = it.message }
                    }
                },
                enabled = !working && state.originalSegments.isNotEmpty() && geminiKey.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) { Text(tr("تصحيح النص المستخرج بـ Gemini", "Correct extracted text with Gemini")) }
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                scope.launch {
                    error = null; notice = null
                    if (source == target) { error = tr("اختر لغتين مختلفتين", "Choose two different languages"); return@launch }
                    working = true; progress = 0
                    val segs = state.originalSegments
                    val r = when (engine) {
                        "gemini" -> GeminiAssistant.translateSegments(geminiKey, geminiModel, source, target, segs) { progress = it }
                        "online" -> {
                            val o = OnlineTranslator.translateSegments(context, source, target, segs) { progress = it }
                            if (o.isSuccess) o else {
                                notice = tr("تعذّرت الترجمة أونلاين (${o.exceptionOrNull()?.message}). استُخدمت الترجمة دون إنترنت.", "Online translation failed (${o.exceptionOrNull()?.message}). Offline translation was used.")
                                progress = 0
                                TranslatorHelper.translateSegments(source, target, segs) { progress = it }
                            }
                        }
                        else -> TranslatorHelper.translateSegments(source, target, segs) { progress = it }
                    }
                    working = false
                    r.onSuccess {
                        appViewModel.setTranslatedSegments(it, source, target)
                        if (engine == "gemini") notice = tr("تمت الترجمة بنموذج ${GeminiAssistant.lastModelUsed}", "Translated with ${GeminiAssistant.lastModelUsed}")
                    }.onFailure { error = it.message }
                }
            },
            enabled = !working && state.originalSegments.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            if (working) {
                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp)); Text("$progress%")
            } else Text(tr("ترجمة", "Translate"))
        }
        if (state.originalSegments.isEmpty()) {
            Text(tr("لم يتم استخراج النص بعد. ارجع إلى شاشة الاستخراج.", "No text extracted yet. Go back to the extraction screen."), color = WarnYellow, fontSize = 12.sp)
        }
        Text(tr("ترجمة ML Kit تنزّل نموذج كل لغة عند أول استخدام (تحتاج إنترنت). Gemini يحتاج مفتاح API واتصالًا بالإنترنت.", "ML Kit downloads each language model on first use (needs internet). Gemini requires an API key and internet access."), color = TextGray, fontSize = 11.sp)
        notice?.let { Text(it, color = WarnYellow, fontSize = 12.sp) }
        error?.let { Text(it, color = ErrRed, fontSize = 14.sp) }
        if (state.translatedSegments.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            state.translatedSegments.forEach {
                Card(Modifier.fillMaxWidth().padding(vertical = 2.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
                    Text(it.text, Modifier.padding(8.dp), color = TextWhite)
                }
            }
            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClick = onEdit, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                Text(tr("✏️ تعديل / نسخ / لصق الترجمة", "✏️ Edit / copy / paste translation"))
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onDone, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Secondary)) {
                Text(tr("تخصيص الترجمة", "Customize subtitles"))
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun LangDropdown(label: String, selected: String, modifier: Modifier, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$label: ${langs.firstOrNull { it.first == selected }?.second ?: selected}", color = TextWhite)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            langs.forEach { (c, n) -> DropdownMenuItem(text = { Text(n) }, onClick = { onSelect(c); expanded = false }) }
        }
    }
}
