package com.waleed.subgenius.ui.screens

import android.content.Intent
import android.net.Uri
import android.speech.tts.TextToSpeech
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.waleed.subgenius.data.model.Project
import com.waleed.subgenius.data.repository.ProjectRepository
import com.waleed.subgenius.engine.DubbingHelper
import com.waleed.subgenius.engine.MediaSaver
import com.waleed.subgenius.engine.VoiceOption
import com.waleed.subgenius.tr
import com.waleed.subgenius.ui.AppViewModel
import com.waleed.subgenius.ui.components.TopBar
import com.waleed.subgenius.ui.theme.BgDark
import com.waleed.subgenius.ui.theme.ErrRed
import com.waleed.subgenius.ui.theme.OkGreen
import com.waleed.subgenius.ui.theme.Primary
import com.waleed.subgenius.ui.theme.Secondary
import com.waleed.subgenius.ui.theme.TextGray
import com.waleed.subgenius.ui.theme.TextWhite
import com.waleed.subgenius.ui.theme.WarnYellow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DubbingScreen(appViewModel: AppViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val state by appViewModel.state.collectAsState()
    val segs = state.translatedSegments.ifEmpty { state.originalSegments }
    val lang = if (state.translatedSegments.isNotEmpty()) state.targetLang else state.sourceLang

    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsChecked by remember { mutableStateOf(false) }
    var voices by remember { mutableStateOf<List<VoiceOption>>(emptyList()) }
    var selected by remember { mutableStateOf<String?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    var rate by remember { mutableFloatStateOf(1.0f) }
    var pitch by remember { mutableFloatStateOf(1.0f) }
    var bg by remember { mutableFloatStateOf(0.25f) }
    var working by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }
    var savedUri by remember { mutableStateOf<Uri?>(null) }
    val hScroll = rememberScrollState()

    LaunchedEffect(Unit) { tts = DubbingHelper.initTts(context); ttsChecked = true }
    DisposableEffect(Unit) { onDispose { tts?.stop(); tts?.shutdown() } }
    LaunchedEffect(tts, lang) {
        val t = tts ?: return@LaunchedEffect
        voices = DubbingHelper.voicesFor(t, lang)
        if (voices.none { it.name == selected }) selected = voices.firstOrNull()?.name
    }

    Column(Modifier.fillMaxSize().background(BgDark).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        TopBar(tr("دبلجة صوتية", "Voice dubbing"), onBack)
        Text(
            tr("لغة الدبلجة: $lang • عدد المقاطع: ${segs.size}", "Dubbing language: $lang • Segments: ${segs.size}"),
            color = TextWhite, fontSize = 14.sp
        )
        if (segs.isEmpty()) {
            Text(tr("لا يوجد نص. استخرج النص (وترجمه إن أردت) أولاً.", "No text. Extract (and optionally translate) the text first."), color = WarnYellow, fontSize = 12.sp)
        }
        Spacer(Modifier.height(12.dp))

        if (ttsChecked && tts == null) {
            Text(tr("لا يوجد محرك تحويل نص إلى كلام على هاتفك. ثبّت Google Text-to-speech من المتجر.", "No text-to-speech engine on your phone. Install Google Text-to-speech from the store."), color = ErrRed, fontSize = 13.sp)
        } else {
            Text(tr("الصوت:", "Voice:"), color = TextGray, fontSize = 12.sp)
            Box {
                OutlinedButton(onClick = { menuOpen = true }, modifier = Modifier.fillMaxWidth(), enabled = !working && voices.isNotEmpty()) {
                    Text(voices.firstOrNull { it.name == selected }?.label ?: tr("جارٍ التحميل…", "Loading…"), color = TextWhite)
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    voices.forEach { v ->
                        DropdownMenuItem(text = { Text(v.label) }, onClick = { selected = v.name; menuOpen = false })
                    }
                }
            }
            Text(
                tr("الأصوات المعروضة هي ما هو مثبّت على هاتفك فقط. لإضافة أصوات: إعدادات الهاتف ← تحويل النص إلى كلام ← Google ← تثبيت بيانات الصوت.",
                   "Only voices installed on your phone are listed. To add more: Phone settings → Text-to-speech → Google → Install voice data."),
                color = TextGray, fontSize = 11.sp
            )
            OutlinedButton(
                onClick = {
                    val i = Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try { context.startActivity(i) } catch (e: Exception) {
                        try { context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            ) { Text(tr("فتح إعدادات تحويل النص إلى كلام", "Open text-to-speech settings"), color = TextWhite) }

            Spacer(Modifier.height(12.dp))
            Text(tr("نبرة الصوت (لتمييز الأصوات):", "Voice tone (to tell voices apart):"), color = TextGray, fontSize = 12.sp)
            Row(Modifier.horizontalScroll(hScroll), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    Triple(0.8f, tr("أعمق", "Deeper"), 0),
                    Triple(1.0f, tr("عادي", "Normal"), 1),
                    Triple(1.25f, tr("أرفع", "Higher"), 2)
                ).forEach { (v, label, _) ->
                    FilterChip(selected = abs(pitch - v) < 0.02f, onClick = { pitch = v }, label = { Text(label) }, enabled = !working)
                }
            }
            Text(tr("النبرة: %.2f".format(Locale.US, pitch), "Pitch: %.2f".format(Locale.US, pitch)), color = TextGray, fontSize = 12.sp)
            Slider(value = pitch, onValueChange = { pitch = it }, valueRange = 0.6f..1.5f, enabled = !working)
            Text(tr("سرعة النطق: %.2f".format(Locale.US, rate), "Speech rate: %.2f".format(Locale.US, rate)), color = TextGray, fontSize = 12.sp)
            Slider(value = rate, onValueChange = { rate = it }, valueRange = 0.6f..1.6f, enabled = !working)
            Text(tr("صوت الفيديو الأصلي: ${(bg * 100).toInt()}%", "Original video audio: ${(bg * 100).toInt()}%"), color = TextGray, fontSize = 12.sp)
            Slider(value = bg, onValueChange = { bg = it }, valueRange = 0f..1f, enabled = !working)

            OutlinedButton(
                onClick = {
                    val t = tts ?: return@OutlinedButton
                    DubbingHelper.applyVoice(t, lang, selected, rate, pitch)
                    val sample = segs.firstOrNull()?.text?.take(120) ?: tr("مرحباً، هذا اختبار للصوت", "Hello, this is a voice test")
                    t.speak(sample, TextToSpeech.QUEUE_FLUSH, null, "preview")
                },
                modifier = Modifier.fillMaxWidth(), enabled = !working && tts != null
            ) { Text(tr("🔊 تجربة الصوت", "🔊 Preview voice"), color = TextWhite) }
            Spacer(Modifier.height(8.dp))

            Button(
                onClick = {
                    val t = tts ?: return@Button
                    val video = state.videoFile ?: run { error = tr("لا يوجد فيديو", "No video"); return@Button }
                    scope.launch {
                        working = true; error = null; savedUri = null; progress = 0
                        val r = DubbingHelper.dub(context, t, video, segs, lang, selected, rate, pitch, bg) { progress = it }
                        val dubbed = r.getOrElse { error = it.message; working = false; return@launch }
                        val name = "SubGenius_dub_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                        val uri = withContext(Dispatchers.IO) { MediaSaver.saveToGallery(context, dubbed, name) }
                        dubbed.delete()
                        working = false
                        if (uri == null) { error = tr("تعذّر حفظ الفيديو في المعرض", "Could not save the video to the gallery"); return@launch }
                        savedUri = uri
                        ProjectRepository(context).insert(
                            Project(name = name, videoUri = state.videoUri ?: "", outputPath = uri.toString(),
                                sourceLang = state.sourceLang, targetLang = state.targetLang, status = "done")
                        )
                    }
                },
                enabled = !working && segs.isNotEmpty() && tts != null,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Primary)
            ) { Text(tr("بدء الدبلجة", "Start dubbing"), fontSize = 16.sp) }
        }

        if (working) {
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth(), color = Primary)
            Text("$progress%", color = TextGray, fontSize = 12.sp)
        }
        error?.let { Text(it, color = ErrRed, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp)) }
        savedUri?.let { u ->
            Text(tr("تمت الدبلجة وحُفظ الفيديو في المعرض (Movies/SubGenius) ✅", "Dubbing done — saved to the gallery (Movies/SubGenius) ✅"), color = OkGreen, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
            OutlinedButton(onClick = { MediaSaver.openVideo(context, u) }, modifier = Modifier.fillMaxWidth()) {
                Text(tr("فتح الفيديو", "Open video"), color = TextWhite)
            }
        }
        Text(
            tr("ملاحظة: بعض الأصوات تتطلب إنترنت (مكتوب بجانبها) وقد يرسل مزوّد الصوت النص إلى خوادمه. الدبلجة تُنتج الفيديو من الأصل دون حرق الترجمة.",
               "Note: some voices need internet (marked next to them) and the voice provider may send the text to its servers. Dubbing is made from the original video, without burned subtitles."),
            color = TextGray, fontSize = 11.sp, modifier = Modifier.padding(top = 12.dp)
        )
        Spacer(Modifier.height(32.dp))
    }
}
