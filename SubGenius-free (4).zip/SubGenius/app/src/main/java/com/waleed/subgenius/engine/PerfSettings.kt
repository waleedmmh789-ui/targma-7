package com.waleed.subgenius.engine

import android.app.ActivityManager
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.waleed.subgenius.tr

enum class Profile { LIGHT, BALANCED, HIGH }

/** القيم التي يتغير بها سلوك التطبيق حسب قوة الهاتف */
data class PerfConfig(
    val profile: Profile,
    val defaultEngineWhisper: Boolean,   // المحرك الافتراضي: Whisper (true) أم Vosk (false)
    val whisperModelId: String,          // النموذج الموصى به: base / small
    val whisperThreads: Int,
    val whisperChunkSec: Int,            // طول المقطع عند تقسيم الصوت الطويل
    val whisperSingleClipSec: Int,       // الأقصر من هذا يُعالج دفعة واحدة (سياق أفضل)
    val voskWorkers: Int,                // عدد خيوط Vosk المتوازية
    val compression: CompressionLevel,   // مستوى الضغط الافتراضي
    val burnMaxHeight: Int,              // أقصى ارتفاع عند الحرق (0 = كما في الأصل)
    val ffmpegThreads: Int,              // خيوط الترميز البرمجي (0 = تلقائي)
    val translateConcurrency: Int,       // طلبات الترجمة المتزامنة
    val releaseModelsAfterUse: Boolean   // تحرير النماذج من الذاكرة بعد كل عملية
)

/** وضع الأداء: تلقائي حسب الجهاز، أو يدوي (ضعيف/متوسط/قوي) */
object PerfSettings {
    private const val PREFS = "settings"
    private const val KEY = "perf_mode"

    /** auto | light | balanced | high */
    var mode by mutableStateOf("auto")
        private set

    @Volatile var detected: Profile = Profile.BALANCED
        private set
    @Volatile var ramMb: Long = 0
        private set
    @Volatile var cores: Int = 1
        private set

    fun init(context: Context) {
        mode = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "auto") ?: "auto"
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(mi)
        ramMb = mi.totalMem / (1024L * 1024L)
        cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        // totalMem يظهر أقل قليلاً من الرام المعلن (هاتف 4GB ≈ 3.7GB)
        detected = when {
            am?.isLowRamDevice == true || ramMb < 4500 || cores <= 4 -> Profile.LIGHT
            ramMb >= 7000 && cores >= 8 -> Profile.HIGH
            else -> Profile.BALANCED
        }
    }

    fun setMode(context: Context, value: String) {
        mode = value
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, value).apply()
    }

    val profile: Profile
        get() = when (mode) {
            "light" -> Profile.LIGHT
            "balanced" -> Profile.BALANCED
            "high" -> Profile.HIGH
            else -> detected
        }

    val config: PerfConfig get() = configFor(profile)

    fun configFor(p: Profile): PerfConfig = when (p) {
        Profile.LIGHT -> PerfConfig(
            Profile.LIGHT, defaultEngineWhisper = false, whisperModelId = "base",
            whisperThreads = 2, whisperChunkSec = 30, whisperSingleClipSec = 60,
            voskWorkers = 1, compression = CompressionLevel.STRONG, burnMaxHeight = 720,
            ffmpegThreads = 2, translateConcurrency = 2, releaseModelsAfterUse = true
        )
        Profile.BALANCED -> PerfConfig(
            Profile.BALANCED, defaultEngineWhisper = true, whisperModelId = "small",
            whisperThreads = (cores / 2).coerceIn(2, 4), whisperChunkSec = 60, whisperSingleClipSec = 180,
            voskWorkers = (cores / 4).coerceIn(1, 2), compression = CompressionLevel.MEDIUM, burnMaxHeight = 1080,
            ffmpegThreads = 0, translateConcurrency = 3, releaseModelsAfterUse = false
        )
        Profile.HIGH -> PerfConfig(
            Profile.HIGH, defaultEngineWhisper = true, whisperModelId = "small",
            whisperThreads = (cores / 2).coerceIn(4, 6), whisperChunkSec = 120, whisperSingleClipSec = 300,
            voskWorkers = (cores / 3).coerceIn(2, 3), compression = CompressionLevel.LIGHT, burnMaxHeight = 0,
            ffmpegThreads = 0, translateConcurrency = 4, releaseModelsAfterUse = false
        )
    }

    fun label(p: Profile): String = when (p) {
        Profile.LIGHT -> tr("اقتصادي (للهواتف الضعيفة)", "Light (weak phones)")
        Profile.BALANCED -> tr("متوازن (للهواتف المتوسطة)", "Balanced (mid-range phones)")
        Profile.HIGH -> tr("أداء عالٍ (للهواتف القوية)", "High (strong phones)")
    }

    fun description(p: Profile): String = when (p) {
        Profile.LIGHT -> tr(
            "يفضّل Vosk السريع، ونموذج Whisper Base، ومقاطع صغيرة وخيوطاً أقل، وضغطاً أقوى، وحرق الفيديو بدقة حتى 720p، وتحرير النماذج من الذاكرة بعد كل عملية. أبطأ في الجودة لكنه أكثر استقراراً ويقلل السخونة وانغلاق التطبيق.",
            "Prefers fast Vosk, the Whisper Base model, small chunks and fewer threads, stronger compression, burns video at up to 720p, and frees models from memory after each job. Lower quality but more stable, with less heat and fewer crashes."
        )
        Profile.BALANCED -> tr(
            "Whisper Small للدقة، ومقاطع متوسطة، وحرق حتى 1080p، وضغطاً متوسطاً، وخيوطاً معتدلة.",
            "Whisper Small for accuracy, medium chunks, burn up to 1080p, medium compression and moderate threads."
        )
        Profile.HIGH -> tr(
            "Whisper Small بخيوط أكثر، ومقاطع أطول لسياق أفضل (دفعة واحدة حتى 5 دقائق)، وحرق بدقة الفيديو الأصلية، وضغطاً خفيفاً، ومعالجة متوازية أكبر، مع إبقاء النماذج في الذاكرة لتسريع التكرار.",
            "Whisper Small with more threads, longer chunks for better context (single pass up to 5 minutes), burn at the original resolution, light compression, more parallel work, and keeps models in memory to speed up repeated jobs."
        )
    }
}
