package com.waleed.subgenius.ui.screens

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.waleed.subgenius.engine.PerfSettings
import com.waleed.subgenius.engine.Profile
import com.waleed.subgenius.tr
import com.waleed.subgenius.ui.components.TopBar
import com.waleed.subgenius.ui.theme.BgDark
import com.waleed.subgenius.ui.theme.Secondary
import com.waleed.subgenius.ui.theme.SurfaceDark
import com.waleed.subgenius.ui.theme.TextGray
import com.waleed.subgenius.ui.theme.TextWhite

@Composable
fun PerformanceScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val mode = PerfSettings.mode
    val detected = PerfSettings.detected

    Column(Modifier.fillMaxSize().background(BgDark).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        TopBar(tr("وضع الأداء", "Performance mode"), onBack)

        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
            Column(Modifier.padding(16.dp)) {
                Text(tr("جهازك", "Your device"), color = Secondary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text(
                    tr("الذاكرة: ≈ %.1f GB • الأنوية: %d • أندرويد %s".format(PerfSettings.ramMb / 1024.0, PerfSettings.cores, Build.VERSION.RELEASE),
                       "Memory: ≈ %.1f GB • Cores: %d • Android %s".format(PerfSettings.ramMb / 1024.0, PerfSettings.cores, Build.VERSION.RELEASE)),
                    color = TextWhite, fontSize = 13.sp
                )
                Text(
                    tr("التوصية التلقائية: ${PerfSettings.label(detected)}", "Automatic recommendation: ${PerfSettings.label(detected)}"),
                    color = TextGray, fontSize = 12.sp
                )
            }
        }
        Spacer(Modifier.height(12.dp))

        Option(
            selected = mode == "auto",
            title = tr("تلقائي (موصى به)", "Automatic (recommended)"),
            body = tr("يختار التطبيق الوضع المناسب لهاتفك: ${PerfSettings.label(detected)}.", "The app picks the right mode for your phone: ${PerfSettings.label(detected)}.")
        ) { PerfSettings.setMode(context, "auto") }

        listOf("light" to Profile.LIGHT, "balanced" to Profile.BALANCED, "high" to Profile.HIGH).forEach { (id, p) ->
            Option(selected = mode == id, title = PerfSettings.label(p), body = PerfSettings.description(p)) {
                PerfSettings.setMode(context, id)
            }
        }

        Text(
            tr("يمكنك تغيير الوضع في أي وقت. إن كان تطبيقك يبطؤ أو يتوقف أو يسخن فاختر «اقتصادي». وإن كان هاتفك قوياً وتريد أعلى جودة فاختر «أداء عالٍ». يُطبَّق التغيير على العمليات التالية.",
               "You can change the mode at any time. If the app is slow, freezes, or heats up, choose Light. If your phone is strong and you want the best quality, choose High. The change applies to the next jobs."),
            color = TextGray, fontSize = 11.sp, modifier = Modifier.padding(vertical = 8.dp)
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Option(selected: Boolean, title: String, body: String, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
            RadioButton(selected = selected, onClick = onClick)
            Column(Modifier.weight(1f).padding(top = 10.dp)) {
                Text(title, color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(body, color = TextGray, fontSize = 12.sp)
            }
        }
    }
}
