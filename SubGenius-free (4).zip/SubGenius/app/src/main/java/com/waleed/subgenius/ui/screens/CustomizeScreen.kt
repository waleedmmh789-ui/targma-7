package com.waleed.subgenius.ui.screens

import com.waleed.subgenius.tr

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.waleed.subgenius.data.model.Project
import com.waleed.subgenius.data.repository.ProjectRepository
import com.waleed.subgenius.engine.FFmpegHelper
import com.waleed.subgenius.engine.MediaSaver
import com.waleed.subgenius.engine.SubtitleBuilder
import com.waleed.subgenius.engine.SubtitleStyle
import com.waleed.subgenius.ui.AppViewModel
import com.waleed.subgenius.ui.components.TopBar
import com.waleed.subgenius.ui.theme.BgDark
import com.waleed.subgenius.ui.theme.ErrRed
import com.waleed.subgenius.ui.theme.OkGreen
import com.waleed.subgenius.ui.theme.TextGray
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CustomizeScreen(appViewModel: AppViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val state by appViewModel.state.collectAsState()
    var fontSize by remember { mutableFloatStateOf(22f) }
    var working by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var savedUri by remember { mutableStateOf<Uri?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().background(BgDark).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        TopBar(tr("حرق الترجمة", "Burn subtitles"), onBack)
        Spacer(Modifier.height(8.dp))
        Card(Modifier.fillMaxWidth().height(180.dp), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.Black)) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
                Box(Modifier.padding(bottom = 24.dp).background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(4.dp)).padding(8.dp)) {
                    Text(tr("مرحبا بكم في التطبيق", "Welcome to the app"), color = Color.White, fontSize = (fontSize * 0.8f).sp)
                }
            }
        }
        Text(tr("حجم الخط: ${fontSize.toInt()}", "Font size: ${fontSize.toInt()}"), color = TextGray, fontSize = 14.sp)
        Slider(value = fontSize, onValueChange = { fontSize = it }, valueRange = 12f..40f)
        Spacer(Modifier.height(16.dp))

        Button(
            onClick = {
                scope.launch {
                    working = true; error = null; savedUri = null; progress = 0
                    val segs = state.translatedSegments.ifEmpty { state.originalSegments }
                    val video = state.videoFile
                    if (segs.isEmpty() || video == null) {
                        error = tr("لا يوجد نص. ارجع واستخرج النص أولاً.", "No text. Go back and extract the text first."); working = false; return@launch
                    }
                    val lang = if (state.translatedSegments.isNotEmpty()) state.targetLang else state.sourceLang
                    val style = SubtitleStyle(fontSize = fontSize.toInt(), fontName = SubtitleStyle.fontNameFor(lang))
                    val ass = SubtitleBuilder.buildAss(context, segs, style).getOrElse { error = it.message; working = false; return@launch }
                    val r = FFmpegHelper.burnSubtitles(context, video, ass) { progress = it }
                    ass.delete()
                    val burned = r.getOrElse { error = it.message; working = false; return@launch }
                    val name = "SubGenius_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                    val uri = withContext(Dispatchers.IO) { MediaSaver.saveToGallery(context, burned, name) }
                    burned.delete()
                    working = false
                    if (uri == null) { error = tr("تعذّر حفظ الفيديو في المعرض", "Could not save the video to the gallery"); return@launch }
                    savedUri = uri
                    ProjectRepository(context).insert(
                        Project(
                            name = name, videoUri = state.videoUri ?: "", outputPath = uri.toString(),
                            sourceLang = state.sourceLang, targetLang = state.targetLang, status = "done"
                        )
                    )
                }
            },
            enabled = !working,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = ErrRed)
        ) {
            if (working) {
                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp)); Text("$progress%")
            } else Text(tr("بدء الحرق النهائي", "Start final burn"))
        }
        error?.let { Text(it, color = ErrRed, fontSize = 14.sp) }
        savedUri?.let { u ->
            Spacer(Modifier.height(8.dp))
            Text(tr("تم الحفظ في المعرض (Movies/SubGenius) ✅", "Saved to the gallery (Movies/SubGenius) ✅"), color = OkGreen, fontSize = 14.sp)
            OutlinedButton(onClick = { MediaSaver.openVideo(context, u) }, modifier = Modifier.fillMaxWidth()) { Text(tr("فتح الفيديو", "Open video")) }
        }
        Spacer(Modifier.height(24.dp))
    }
}
