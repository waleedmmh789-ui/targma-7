# عبقري الترجمة (SubGenius)

## البناء
- محلياً: افتح المشروع في Android Studio (Ladybug أو أحدث) ثم Run. لا يوجد gradlew في الحزمة؛ Android Studio ينشئ الـ wrapper تلقائياً.
- GitHub Actions: ارفع المشروع ثم شغّل workflow. يُنتج APK debug دائماً.
  للتوقيع أضف Secrets: KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD.

## قبل النشر
1. غيّر `com.waleed.subgenius` إلى اسم حزمتك.
2. إن فشل تحميل `dev.ffmpegkit-maintained:ffmpeg-kit-full` ضع ملف .aar داخل `app/libs/`.
3. محركان للتعرف على الكلام: Whisper (الأدق للهجات، نماذج من huggingface.co/ggerganov/whisper.cpp) وVosk (أخف وأسرع). تحقق من روابط النماذج في `WhisperModelDownloader.kt` و`VoskModelDownloader.kt`.
   إن لم يُحمَّل `whisper-android:1.0.0` من Maven جرّب `0.1.2` أو JitPack.
4. التطبيق مجاني بالكامل: لا فوترة ولا اشتراكات.
5. الخط العربي: يُستخدم خط النظام تلقائياً. لخط محدد ضع ملف .ttf في `app/src/main/assets/fonts/`.

## Gemini AI integration

The Translate screen now includes an optional Gemini AI engine. Enter a Gemini API key in the screen to translate subtitle segments or review a previously extracted transcript. Transcript review is intended to correct likely recognition errors while preserving Egyptian Arabic dialect and segment timing.

- The API key is kept only in the current screen state and is not written to SharedPreferences or source files.
- Do not commit API keys to GitHub. For a public production app, proxy Gemini requests through a trusted backend so the key is not exposed in the APK.
- Gemini processing requires internet access and may incur API charges or be subject to quota limits. Audio/text content submitted for processing is sent to Google.
- Always review the corrected transcript before exporting subtitles; AI correction can still make mistakes.
