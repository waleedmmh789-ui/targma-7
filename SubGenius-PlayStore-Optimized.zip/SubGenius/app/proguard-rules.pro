# Keep JNI native method names so native speech engines can bind safely.
-keepclasseswithmembernames,includedescriptorclasses class * { native <methods>; }

# Vosk uses JNI and reflective/native bindings.
-keep class org.vosk.** { *; }
-keep class com.alphacephei.vosk.** { *; }

# Sherpa-ONNX / Moonshine uses JNI bindings.
-keep class com.k2fsa.sherpa.onnx.** { *; }
-keep class com.xdcobra.sherpa.** { *; }

# JNA is used by native integrations.
-keep class com.sun.jna.** { *; }
-dontwarn com.sun.jna.**
