package com.waleed.subgenius.ui.screens

import com.waleed.subgenius.tr

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.waleed.subgenius.engine.OnlineTranslator
import com.waleed.subgenius.engine.GeminiAssistant
import com.waleed.subgenius.engine.TranslatorHelper
import com.waleed.subgenius.ui.AppViewModel
import com.waleed.subgenius.ui.components.TopBar
import com.waleed.subgenius.ui.theme.BgDark
import com.waleed.subgenius.ui.theme.ErrRed
import com.waleed.subgenius.ui.theme.Secondary
import com.waleed.subgenius.ui.theme.SurfaceDark
import com.waleed.subgenius.ui.theme.TextGray
import com.waleed.subgenius.ui.theme.TextWhite
import com.waleed.subgenius.ui.theme.WarnYellow
import kotlinx.coroutines.launch

private val langs = listOf(
    "ar" to "العربية", "en" to "English", "fr" to "Français", "es" to "Español", "de" to "Deutsch",
    "tr" to "Türkçe", "ru" to "Русский", "zh" to "中文", "ja" to "日本語", "el" to "Ελληνικά"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TranslateScreen(appViewModel: AppViewModel, onBack: () -> Unit, onDone: () -> Unit, onEdit: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val state by appViewModel.state.collectAsState()
    var source by remember { mutableStateOf(state.sourceLang) }
    var target by remember {
        mutableStateOf(if (state.targetLang == state.sourceLang) (if (state.sourceLang == "ar") "en" else "ar") else state.targetLang)
    }
    var engine by remember { mutableStateOf("online") }
    var geminiKey by remember { mutableStateOf("") }
    var lingvaUrl by remember { mutableStateOf(OnlineTranslator.getCustomLingva(context)) }
    var working by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }
    var notice by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().background(BgDark).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        TopBar(tr("ترجمة النص", "Translate text"), onBack)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            LangDropdown(tr("من", "From"), source, Modifier.weight(1f)) { source = it }
            LangDropdown(tr("إلى", "To"), target, Modifier.weight(1f)) { target = it }
        }
        Spacer(Modifier.height(12.dp))
        Text(tr("محرك الترجمة:", "Translation engine:"), color = TextGray, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = engine == "online", onClick = { engine = "online" }, label = { Text(tr("أونلاين مجاني", "Free online")) }, enabled = !working)
            FilterChip(selected = engine == "gemini", onClick = { engine = "gemini" }, label = { Text("Gemini AI") }, enabled = !working)
            FilterChip(selected = engine == "offline", onClick = { engine = "offline" }, label = { Text(tr("بدون إنترنت", "Offline")) }, enabled = !working)
        }
        if (engine == "online") {
            Text(
                tr("يُرسل النص إلى خوادم Lingva ثم MyMemory المجانية. قد تتوقف أو تُحدّ، وعندها تُستخدم الترجمة دون إنترنت تلقائياً.", "The text is sent to the free Lingva then MyMemory servers. They may go down or be rate-limited, in which case offline translation is used automatically."),
                color = TextGray, fontSize = 11.sp
            )
            OutlinedTextField(
                value = lingvaUrl,
                onValueChange = { lingvaUrl = it; OnlineTranslator.setCustomLingva(context, it) },
                label = { Text(tr("خادم Lingva خاص (اختياري، https://...)", "Custom Lingva server (optional, https://...)")) },
                singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = !working
            )
        }
        if (engine == "gemini") {
            OutlinedTextField(
                value = geminiKey,
                onValueChange = { geminiKey = it },
                label = { Text(tr("مفتاح Gemini API", "Gemini API key")) },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                enabled = !working
            )
            Text(
                tr("يتصل التطبيق بـ Gemini عبر الإنترنت. لا تحفظ المفتاح داخل المشروع أو GitHub؛ للإصدار العام استخدم خادمًا وسيطًا آمنًا. النصوص تُرسل إلى Google لمعالجتها.", "Connects to Gemini online. Do not commit the key to the project or GitHub; use a secure backend proxy for public releases. Text is sent to Google for processing."),
                color = WarnYellow, fontSize = 11.sp
            )
            OutlinedButton(
                onClick = {
                    scope.launch {
                        error = null; notice = null; working = true; progress = 0
                        val r = GeminiAssistant.correctTranscript(geminiKey, source, state.originalSegments) { progress = it }
                        working = false
                        r.onSuccess { appViewModel.setOriginalSegments(it, source); notice = tr("تمت مراجعة النص باستخدام Gemini. راجع النتيجة قبل اعتمادها.", "Transcript reviewed by Gemini. Check the result before using it.") }
                            .onFailure { error = it.message }
                    }
                },
                enabled = !working && state.originalSegments.isNotEmpty() && geminiKey.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) { Text(tr("تصحيح النص المستخرج بـ Gemini", "Correct extracted text with Gemini")) }
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                scope.launch {
                    error = null; notice = null
                    if (source == target) { error = tr("اختر لغتين مختلفتين", "Choose two different languages"); return@launch }
                    working = true; progress = 0
                    val segs = state.originalSegments
                    val r = when (engine) {
                        "gemini" -> GeminiAssistant.translateSegments(geminiKey, source, target, segs) { progress = it }
                        "online" -> {
                            val o = OnlineTranslator.translateSegments(context, source, target, segs) { progress = it }
                            if (o.isSuccess) o else {
                                notice = tr("تعذّرت الترجمة أونلاين (${o.exceptionOrNull()?.message}). استُخدمت الترجمة دون إنترنت.", "Online translation failed (${o.exceptionOrNull()?.message}). Offline translation was used.")
                                progress = 0
                                TranslatorHelper.translateSegments(source, target, segs) { progress = it }
                            }
                        }
                        else -> TranslatorHelper.translateSegments(source, target, segs) { progress = it }
                    }
                    working = false
                    r.onSuccess { appViewModel.setTranslatedSegments(it, source, target) }
                        .onFailure { error = it.message }
                }
            },
            enabled = !working && state.originalSegments.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            if (working) {
                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp)); Text("$progress%")
            } else Text(tr("ترجمة", "Translate"))
        }
        if (state.originalSegments.isEmpty()) {
            Text(tr("لم يتم استخراج النص بعد. ارجع إلى شاشة الاستخراج.", "No text extracted yet. Go back to the extraction screen."), color = WarnYellow, fontSize = 12.sp)
        }
        Text(tr("ترجمة ML Kit تنزّل نموذج كل لغة عند أول استخدام (تحتاج إنترنت). Gemini يحتاج مفتاح API واتصالًا بالإنترنت.", "ML Kit downloads each language model on first use (needs internet). Gemini requires an API key and internet access."), color = TextGray, fontSize = 11.sp)
        notice?.let { Text(it, color = WarnYellow, fontSize = 12.sp) }
        error?.let { Text(it, color = ErrRed, fontSize = 14.sp) }
        if (state.translatedSegments.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            state.translatedSegments.forEach {
                Card(Modifier.fillMaxWidth().padding(vertical = 2.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
                    Text(it.text, Modifier.padding(8.dp), color = TextWhite)
                }
            }
            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClick = onEdit, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                Text(tr("✏️ تعديل / نسخ / لصق الترجمة", "✏️ Edit / copy / paste translation"))
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onDone, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Secondary)) {
                Text(tr("تخصيص الترجمة", "Customize subtitles"))
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun LangDropdown(label: String, selected: String, modifier: Modifier, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$label: ${langs.firstOrNull { it.first == selected }?.second ?: selected}", color = TextWhite)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            langs.forEach { (c, n) -> DropdownMenuItem(text = { Text(n) }, onClick = { onSelect(c); expanded = false }) }
        }
    }
}
