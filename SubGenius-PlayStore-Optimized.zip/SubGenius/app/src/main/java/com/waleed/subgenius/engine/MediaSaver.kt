package com.waleed.subgenius.engine

import com.waleed.subgenius.tr

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import java.io.File

object MediaSaver {
    /** يحفظ الفيديو في معرض الصور (Movies/SubGenius). يتطلب minSdk 29 */
    fun saveToGallery(context: Context, file: File, displayName: String): Uri? {
        if (!file.exists() || !file.isFile || file.length() <= 0L) return null
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "$displayName.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/SubGenius")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            val output = resolver.openOutputStream(uri, "w")
                ?: throw IllegalStateException("تعذّر فتح ملف الحفظ")
            output.use { out -> file.inputStream().use { input -> input.copyTo(out) } }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            if (resolver.update(uri, values, null, null) <= 0) {
                throw IllegalStateException("تعذّر إنهاء حفظ الفيديو")
            }
            uri
        } catch (_: Exception) {
            // Remove incomplete MediaStore rows so failed saves do not leave ghost files.
            runCatching { resolver.delete(uri, null, null) }
            null
        }
    }

    fun openVideo(context: Context, uri: Uri) {
        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            Toast.makeText(context, tr("تعذّر فتح الفيديو", "Could not open the video"), Toast.LENGTH_SHORT).show()
        }
    }
}
