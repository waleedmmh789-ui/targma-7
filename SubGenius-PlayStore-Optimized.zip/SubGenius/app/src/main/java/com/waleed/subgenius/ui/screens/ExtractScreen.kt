package com.waleed.subgenius.ui.screens

import android.app.ActivityManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.waleed.subgenius.engine.FFmpegHelper
import com.waleed.subgenius.engine.SpeechToText
import com.waleed.subgenius.engine.VoskModelDownloader
import com.waleed.subgenius.engine.WhisperModelDownloader
import com.waleed.subgenius.engine.WhisperSpeech
import com.waleed.subgenius.engine.MoonshineModelDownloader
import com.waleed.subgenius.engine.MoonshineSpeech
import com.waleed.subgenius.tr
import com.waleed.subgenius.ui.AppViewModel
import com.waleed.subgenius.ui.components.TopBar
import com.waleed.subgenius.ui.theme.BgDark
import com.waleed.subgenius.ui.theme.ErrRed
import com.waleed.subgenius.ui.theme.Primary
import com.waleed.subgenius.ui.theme.Secondary
import com.waleed.subgenius.ui.theme.TextGray
import com.waleed.subgenius.ui.theme.TextWhite
import kotlinx.coroutines.launch

private enum class SttEngine { WHISPER, VOSK, MOONSHINE }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExtractScreen(appViewModel: AppViewModel, onBack: () -> Unit, onDone: () -> Unit, onEdit: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val state by appViewModel.state.collectAsState()
    var engine by remember { mutableStateOf(SttEngine.WHISPER) }
    var direct by remember { mutableStateOf(false) }
    var modelId by remember { mutableStateOf<String?>(null) }
    var working by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var stage by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val hScroll = rememberScrollState()

    val voskLangs = VoskModelDownloader.models.map { it.lang to it.label }
    val langs = when (engine) { SttEngine.WHISPER -> WhisperSpeech.languages; SttEngine.VOSK -> voskLangs; SttEngine.MOONSHINE -> listOf("ar" to "العربية") }
    // نماذج Whisper المنزَّلة (الأعلى دقة أولاً). الاختيار بينها هو أهم وسيلة لتسريع Whisper.
    val downloaded = WhisperModelDownloader.models.filter { WhisperModelDownloader.isDownloaded(context, it) }
    val isLowRamDevice = remember(context) {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val info = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(info)
        am?.isLowRamDevice == true || info.totalMem <= 4L * 1024L * 1024L * 1024L
    }
    // Prefer Base on low-memory devices unless the user explicitly selects another model.
    val defaultModel = if (isLowRamDevice) downloaded.firstOrNull { it.id == "base" } else null
    val chosen = downloaded.firstOrNull { it.id == modelId } ?: defaultModel ?: downloaded.firstOrNull()

    Column(Modifier.fillMaxSize().background(BgDark).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        TopBar(tr("استخراج النص", "Extract text"), onBack)
        Spacer(Modifier.height(8.dp))

        Text(tr("محرك التعرف على الكلام:", "Speech recognition engine:"), color = TextGray, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = engine == SttEngine.WHISPER, onClick = { engine = SttEngine.WHISPER },
                label = { Text(tr("Whisper — أدق (اللهجات)", "Whisper — more accurate (dialects)")) }, enabled = !working
            )
            FilterChip(
                selected = engine == SttEngine.VOSK,
                onClick = {
                    engine = SttEngine.VOSK
                    if (voskLangs.none { it.first == state.audioLang }) appViewModel.setAudioLang("ar")
                },
                label = { Text(tr("Vosk — أسرع (فصحى)", "Vosk — faster (standard Arabic)")) }, enabled = !working
            )
            FilterChip(
                selected = engine == SttEngine.MOONSHINE,
                onClick = { engine = SttEngine.MOONSHINE; if (state.audioLang != "ar") appViewModel.setAudioLang("ar") },
                label = { Text("Moonshine — عربي") }, enabled = !working
            )
        }
        if (engine == SttEngine.MOONSHINE) {
            Spacer(Modifier.height(8.dp))
            val moonshineReady = MoonshineModelDownloader.isDownloaded(context)
            if (!moonshineReady) {
                OutlinedButton(
                    onClick = {
                        scope.launch {
                            working = true; error = null; progress = 0
                            val result = MoonshineModelDownloader.download(context) { progress = it; stage = tr("تنزيل نموذج Moonshine", "Downloading Moonshine model") }
                            working = false
                            result.onFailure { error = it.message ?: tr("فشل تنزيل النموذج", "Model download failed") }
                        }
                    }, modifier = Modifier.fillMaxWidth(), enabled = !working
                ) { Text(tr("تنزيل نموذج Moonshine العربي (~135 MB)", "Download Arabic Moonshine model (~135 MB)")) }
            } else {
                Text(tr("نموذج Moonshine العربي جاهز دون إنترنت.", "Arabic Moonshine model is ready for offline use."), color = TextGray, fontSize = 11.sp)
            }
        }

        if (engine == SttEngine.WHISPER && downloaded.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Text(tr("حجم نموذج Whisper:", "Whisper model size:"), color = TextGray, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                downloaded.forEach { m ->
                    FilterChip(
                        selected = chosen?.id == m.id, onClick = { modelId = m.id },
                        label = {
                            Text(
                                if (m.id == "base") tr("Base — أسرع", "Base — faster")
                                else tr("Small — أدق وأبطأ", "Small — more accurate, slower")
                            )
                        },
                        enabled = !working
                    )
                }
            }
            Text(
                tr("للهواتف القديمة أو محدودة الذاكرة: نموذج Base أخف. كل الفيديوهات تُعالج على دفعات صغيرة تتغير حسب ذاكرة الهاتف. اختر اللغة العربية يدويًا.",
                   "For older/low-memory phones, Base is lighter. All videos are processed in small memory-adaptive chunks. Select Arabic manually."),
                color = TextGray, fontSize = 11.sp
            )
        }
        Spacer(Modifier.height(12.dp))

        Text(tr("لغة الكلام في الفيديو:", "Spoken language in the video:"), color = TextGray, fontSize = 12.sp)
        Row(Modifier.horizontalScroll(hScroll), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            langs.forEach { (code, label) ->
                FilterChip(
                    selected = state.audioLang == code, onClick = { appViewModel.setAudioLang(code) },
                    label = { Text(label) }, enabled = !working
                )
            }
        }

        if (engine == SttEngine.WHISPER && state.audioLang != "en") {
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("ترجمة مباشرة إلى الإنجليزية", "Translate directly to English"), color = TextWhite, fontSize = 14.sp)
                    Text(
                        tr("أدق للهجات: يترجم من الصوت مباشرة، ثم يمكنك ترجمة الإنجليزية إلى أي لغة أخرى.",
                           "More accurate for dialects: translates straight from the audio, then you can translate the English into any other language."),
                        color = TextGray, fontSize = 11.sp
                    )
                }
                Switch(checked = direct, onCheckedChange = { direct = it }, enabled = !working)
            }
        }
        Spacer(Modifier.height(16.dp))

        if (!working && state.originalSegments.isEmpty()) {
            Button(
                onClick = {
                    scope.launch {
                        error = null
                        val file = state.videoFile ?: run { error = tr("لا يوجد فيديو", "No video"); return@launch }
                        val lang = state.audioLang
                        val useDirect = engine == SttEngine.WHISPER && direct && lang != "en"
                        val modelPath = when (engine) {
                            SttEngine.WHISPER -> chosen?.let { WhisperModelDownloader.file(context, it).absolutePath }
                            SttEngine.VOSK -> VoskModelDownloader.getModelPath(context, lang)
                            SttEngine.MOONSHINE -> MoonshineModelDownloader.modelDir(context).absolutePath.takeIf { MoonshineModelDownloader.isDownloaded(context) }
                        }
                        if (modelPath == null) {
                            error = tr("نموذج هذا المحرك غير مُنزَّل. نزّله من «تنزيل النماذج».", "This engine's model is not downloaded. Get it from 'Download models'.")
                            return@launch
                        }
                        working = true; progress = 0
                        val audio = FFmpegHelper.extractAudio(context, file) { progress = it / 10; stage = tr("استخراج الصوت", "Extracting audio") }
                            .getOrElse { error = it.message; working = false; return@launch }
                        val r = when (engine) {
                            SttEngine.WHISPER -> WhisperSpeech.transcribe(context, audio, modelPath, lang, useDirect) {
                                progress = 10 + it * 9 / 10; stage = tr("التعرف على الكلام (Whisper)", "Recognizing speech (Whisper)")
                            }
                            SttEngine.VOSK -> SpeechToText.transcribe(audio, modelPath) {
                                progress = 10 + it * 9 / 10; stage = tr("التعرف على الكلام (Vosk)", "Recognizing speech (Vosk)")
                            }
                            SttEngine.MOONSHINE -> MoonshineSpeech.transcribe(audio, modelPath) {
                                progress = 10 + it * 9 / 10; stage = tr("التعرف على الكلام (Moonshine)", "Recognizing speech (Moonshine)")
                            }
                        }
                        audio.delete(); working = false
                        r.onSuccess {
                            if (it.isEmpty()) error = tr("لم يُكتشف أي كلام", "No speech detected")
                            else appViewModel.setOriginalSegments(it, if (useDirect) "en" else null)
                        }.onFailure { error = it.message }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(64.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Primary)
            ) { Text(tr("بدء الاستخراج", "Start extraction"), fontSize = 16.sp) }
        }
        if (working) {
            LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth(), color = Primary)
            Text("$stage ($progress%)", color = TextGray, fontSize = 14.sp)
            if (engine == SttEngine.WHISPER) {
                Text(tr("اترك التطبيق مفتوحًا أثناء المعالجة. إذا كانت الكلمات غير دقيقة، أوقف «الترجمة المباشرة إلى الإنجليزية» أولًا للحصول على النص العربي الأصلي.", "Keep the app open while processing. If words are inaccurate, turn off ‘Translate directly to English’ first to get the original Arabic transcript."), color = TextGray, fontSize = 11.sp)
            } else if (engine == SttEngine.MOONSHINE) {
                Text(tr("Moonshine يعالج الصوت على دفعات 15 ثانية لتقليل الذاكرة. التوقيتات تقريبية على مستوى الدفعة.", "Moonshine processes 15-second chunks to reduce memory use. Segment timing is approximate per chunk."), color = TextGray, fontSize = 11.sp)
            }
        }
        error?.let { Text(it, color = ErrRed, fontSize = 14.sp) }

        if (state.originalSegments.isNotEmpty()) {
            Text(
                tr("عدد المقاطع: ${state.originalSegments.size} • لغة النص: ${state.sourceLang}", "Segments: ${state.originalSegments.size} • Text language: ${state.sourceLang}"),
                color = TextWhite
            )
            Spacer(Modifier.height(8.dp))
            state.originalSegments.forEach { Text(it.text, color = TextWhite, fontSize = 14.sp, modifier = Modifier.padding(vertical = 2.dp)) }
            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClick = onEdit, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                Text(tr("✏️ تعديل / نسخ / قص / لصق النص", "✏️ Edit / copy / cut / paste text"))
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = onDone, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Secondary)
            ) { Text(tr("متابعة إلى الترجمة", "Continue to translation")) }
            TextButton(onClick = { appViewModel.clearSegments() }, modifier = Modifier.fillMaxWidth()) { Text(tr("إعادة الاستخراج", "Re-extract")) }
        }
        Spacer(Modifier.height(32.dp))
    }
}
